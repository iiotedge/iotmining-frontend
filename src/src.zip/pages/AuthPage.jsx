"use client"

import React, { useState, useEffect } from "react"
import { Card, Tabs, Typography, Layout } from "antd"
import { useNavigate } from "react-router-dom"
import LoginForm from "../components/auth/LoginForm"
import SignupForm from "../components/auth/SignupForm"
import "../styles/auth.css"
import logo from "../assets/iotmining-logo.svg"

const { Title } = Typography
const { Content } = Layout
const { TabPane } = Tabs

const AuthPage = () => {
  const [activeTab, setActiveTab] = useState("login")
  const [windowWidth, setWindowWidth] = useState(window.innerWidth)
  const navigate = useNavigate()

  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth)
    }

    window.addEventListener("resize", handleResize)
    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  const handleSuccessfulAuth = () => {
    navigate("/")
  }

  return (
    <Layout className="auth-layout">
      <Content className="auth-content">
        <div className="auth-container">
          <div className="auth-logo-container">
          {/* <img src={logo || "/iotmining-logo.svg"} alt="IoT Edge" className="auth-logo" /> */}
            <Title level={windowWidth <= 575 ? 3 : 2} className="auth-title">
              IoTMining Technology
            </Title>
          </div>

          <Card className="auth-card" bordered={false}>
            <Tabs activeKey={activeTab} onChange={setActiveTab} centered className="auth-tabs">
              <TabPane tab="Login" key="login">
                <LoginForm onSuccess={handleSuccessfulAuth} />
              </TabPane>
              <TabPane tab="Sign Up" key="signup">
                <SignupForm onSuccess={() => setActiveTab("login")} />
              </TabPane>
            </Tabs>
          </Card>

          <div className="auth-footer">
            <Typography.Text type="secondary">
              © {new Date().getFullYear()} IoTMining. All rights reserved.
            </Typography.Text>
          </div>
        </div>
      </Content>
    </Layout>
  )
}

export default AuthPage
