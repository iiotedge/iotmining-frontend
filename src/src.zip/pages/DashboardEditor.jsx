"use client"

import { useState, useEffect } from "react"
import { Layout, Button, Space, Input, Typography, message, Modal, Form, Select, Tabs, Dropdown, Menu } from "antd"
import { useParams, useNavigate } from "react-router-dom"
import {
  PlusOutlined,
  ClockCircleOutlined,
  SettingOutlined,
  LinkOutlined,
  FilterOutlined,
  HistoryOutlined,
  CloseOutlined,
  SaveOutlined,
  FullscreenOutlined,
  EditOutlined,
  DeleteOutlined,
  CopyOutlined,
  DownloadOutlined,
  UploadOutlined,
  TeamOutlined,
  DownOutlined,
} from "@ant-design/icons"
import { Responsive, WidthProvider } from "react-grid-layout"
import { saveAs } from "file-saver"
import "react-grid-layout/css/styles.css"
import "react-resizable/css/styles.css"

import WidgetLibrary from "../components/dashboard/WidgetLibrary"
import TimeWindowSettings from "../components/dashboard/TimeWindowSettings"
import DashboardSettings from "../components/dashboard/DashboardSettings"
import ManageLayoutsModal from "../components/dashboard/ManageLayoutsModal"
import ManageStatesModal from "../components/dashboard/ManageStatesModal"
import EntityAliasesModal from "../components/dashboard/EntityAliasesModal"
import WidgetRenderer from "../components/dashboard/WidgetRenderer"
import WidgetConfigModal from "../components/dashboard/WidgetConfigModal"
import { useMediaQuery } from "../hooks/useMediaQuery"
import { getDashboard, createDashboard, updateDashboard } from "../services/api"


const { Header, Content } = Layout
const { Title } = Typography
const { TabPane } = Tabs

const ResponsiveGridLayout = WidthProvider(Responsive)

const DashboardEditor = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [isWidgetLibraryVisible, setIsWidgetLibraryVisible] = useState(false)
  const [isTimeWindowVisible, setIsTimeWindowVisible] = useState(false)
  const [isSettingsVisible, setIsSettingsVisible] = useState(false)
  const [selectedWidget, setSelectedWidget] = useState(null)
  const [isWidgetSettingsVisible, setIsWidgetSettingsVisible] = useState(false)
  const [widgets, setWidgets] = useState([])
  const [layouts, setLayouts] = useState({ lg: [], md: [], sm: [], xs: [] })
  const [isLayoutsModalVisible, setIsLayoutsModalVisible] = useState(false)
  const [isStatesModalVisible, setIsStatesModalVisible] = useState(false)
  const [isAliasesModalVisible, setIsAliasesModalVisible] = useState(false)
  const [dashboardTitle, setDashboardTitle] = useState("New Dashboard")
  const [dashboardSettings, setDashboardSettings] = useState({
    timewindow: {
      realtime: { timewindowMs: 60000 },
      aggregation: { type: "AVG", limit: 200 },
    },
    gridSettings: {
      backgroundColor: "#ffffff",
      columns: 24,
      margin: [10, 10],
      backgroundImage: null,
    },
  })
  const [isImportModalVisible, setIsImportModalVisible] = useState(false)
  const [isAssignCustomerModalVisible, setIsAssignCustomerModalVisible] = useState(false)
  const [isWidgetConfigModalVisible, setIsWidgetConfigModalVisible] = useState(false)
  const [timeWindow, setTimeWindow] = useState({
    displayValue: "Last 15 minutes",
    value: "15_minutes",
    type: "REALTIME",
  })
  const [form] = Form.useForm()
  const isMobile = useMediaQuery("(max-width: 768px)")
  const isTablet = useMediaQuery("(max-width: 992px)")
  const [devices, setDevices] = useState([
    { id: "device1", name: "Temperature Sensor" },
    { id: "device2", name: "Pressure Valve" },
    { id: "device3", name: "Power Meter" },
  ])
  const [customers, setCustomers] = useState([
    { id: "customer1", name: "Demo Customer" },
    { id: "customer2", name: "Device Claiming Customer" },
    { id: "customer3", name: "Customer A" },
  ])
  const [assignedCustomers, setAssignedCustomers] = useState([])

  // Load dashboard data when component mounts
  useEffect(() => {
    console.log("Dashboard Editor loaded with ID:", id)
    // Here you would typically fetch the dashboard data based on the ID
    // For now, we'll just set a default title
    if (id && id !== "new") {
      fetchDashboard(id)
    } else {
      setDashboardTitle("New Dashboard")
    }
  }, [id])

  // const fetchDashboard = async (dashboardId) => {
  //   try {
  //     // In a real app, you would fetch from an API
  //     // For now, we'll simulate a dashboard with mock data
  //     await new Promise((resolve) => setTimeout(resolve, 500)) // Simulate API delay

  //     // Check if this is a predefined dashboard ID
  //     if (dashboardId === "1") {
  //       // Mock dashboard data
  //       const mockDashboard = {
  //         id: dashboardId,
  //         title: "Environmental Monitoring",
  //         widgets: [
  //           {
  //             id: "widget1",
  //             title: "Temperature Sensor",
  //             type: "line-chart",
  //             deviceId: "device1",
  //             deviceName: "Temperature Sensor",
  //             dataKeys: ["temperature", "humidity"],
  //             config: {
  //               title: "Temperature & Humidity",
  //               dataSource: {
  //                 type: "device",
  //                 deviceId: "device1",
  //                 dataKeys: ["temperature", "humidity"],
  //               },
  //               showLegend: true,
  //               showPoints: true,
  //               height: 300,
  //             },
  //           },
  //           {
  //             id: "widget2",
  //             title: "Device Status",
  //             type: "status-card",
  //             deviceId: "device1",
  //             deviceName: "Temperature Sensor",
  //             dataKeys: ["status"],
  //             config: {
  //               title: "Device Status",
  //               dataSource: {
  //                 type: "device",
  //                 deviceId: "device1",
  //                 dataKeys: ["status"],
  //               },
  //               showLastUpdateTime: true,
  //             },
  //           },
  //           {
  //             id: "widget3",
  //             title: "Battery Level",
  //             type: "battery-level",
  //             deviceId: "device1",
  //             deviceName: "Temperature Sensor",
  //             dataKeys: ["batteryLevel"],
  //             config: {
  //               title: "Battery Level",
  //               dataSource: {
  //                 type: "device",
  //                 deviceId: "device1",
  //                 dataKeys: ["batteryLevel"],
  //               },
  //               showValue: true,
  //             },
  //           },
  //         ],
  //         layouts: {
  //           lg: [
  //             { i: "widget1", x: 0, y: 0, w: 8, h: 4 },
  //             { i: "widget2", x: 8, y: 0, w: 4, h: 2 },
  //             { i: "widget3", x: 8, y: 2, w: 4, h: 2 },
  //           ],
  //           md: [
  //             { i: "widget1", x: 0, y: 0, w: 8, h: 4 },
  //             { i: "widget2", x: 8, y: 0, w: 4, h: 2 },
  //             { i: "widget3", x: 8, y: 2, w: 4, h: 2 },
  //           ],
  //           sm: [
  //             { i: "widget1", x: 0, y: 0, w: 12, h: 4 },
  //             { i: "widget2", x: 0, y: 4, w: 6, h: 2 },
  //             { i: "widget3", x: 6, y: 4, w: 6, h: 2 },
  //           ],
  //           xs: [
  //             { i: "widget1", x: 0, y: 0, w: 12, h: 4 },
  //             { i: "widget2", x: 0, y: 4, w: 12, h: 2 },
  //             { i: "widget3", x: 0, y: 6, w: 12, h: 2 },
  //           ],
  //         },
  //         settings: dashboardSettings,
  //         assignedCustomers: ["customer1", "customer2"],
  //       }

  //       setDashboardTitle(mockDashboard.title)
  //       setWidgets(mockDashboard.widgets)
  //       setLayouts(mockDashboard.layouts)
  //       setDashboardSettings(mockDashboard.settings)
  //       setAssignedCustomers(mockDashboard.assignedCustomers)
  //     } else {
  //       setDashboardTitle(`Dashboard ${dashboardId}`)
  //     }
  //   } catch (error) {
  //     console.error("Error fetching dashboard:", error)
  //     message.error("Failed to load dashboard")
  //   }
  // }
  const fetchDashboard = async (dashboardId) => {
    try {
      const dashboard = await getDashboard(dashboardId)
  
      setDashboardTitle(dashboard.title || "Untitled")
      setWidgets(JSON.parse(dashboard.widgets || "[]"))
      setLayouts(JSON.parse(dashboard.layouts || "{}"))
      setDashboardSettings(JSON.parse(dashboard.settings || "{}"))
      setAssignedCustomers(dashboard.assignedCustomers || [])
      setTimeWindow(JSON.parse(dashboard.timewindow || "{}"))
    } catch (error) {
      console.error("Error loading dashboard:", error)
      message.error("Unable to load dashboard from server")
    }
  }
  const handleAddWidget = (widget) => {
    const widgetId = Date.now().toString()
    const newWidget = {
      ...widget,
      id: widgetId,
      config: {
        title: widget.title,
        dataSource: {
          type: "device",
          deviceId: null,
          dataKeys: [],
        },
        // Default configuration based on widget type
        ...(widget.type.includes("chart")
          ? {
              height: 300,
              showLegend: true,
              showPoints: true,
            }
          : {}),
        ...(widget.type.includes("map")
          ? {
              zoom: 4,
              center: { lat: 37.7749, lng: -122.4194 },
            }
          : {}),
      },
    }

    // Add widget to widgets array
    setWidgets([...widgets, newWidget])

    // Create a layout for the new widget
    const newLayout = {
      i: widgetId,
      x: (layouts.lg.length * 4) % 12, // Position based on number of widgets
      y: Number.POSITIVE_INFINITY, // Put it at the bottom
      w: 4, // Default width
      h: 4, // Default height
      minW: 2, // Min width
      minH: 2, // Min height
    }

    // Update layouts for all breakpoints
    setLayouts({
      lg: [...layouts.lg, newLayout],
      md: [...layouts.md, { ...newLayout, w: Math.min(newLayout.w, 8) }],
      sm: [...layouts.sm, { ...newLayout, w: Math.min(newLayout.w * 2, 12), x: 0 }],
      xs: [...layouts.xs, { ...newLayout, w: 12, x: 0 }],
    })

    setIsWidgetLibraryVisible(false)

    // Open widget configuration modal for the new widget
    setSelectedWidget(newWidget)
    setIsWidgetConfigModalVisible(true)
  }

  const handleWidgetSettings = (widget) => {
    setSelectedWidget(widget)
    setIsWidgetConfigModalVisible(true)
  }

  const handleWidgetConfigSave = (updatedWidget) => {
    // Update the widget in the widgets array
    const updatedWidgets = widgets.map((w) => {
      if (w.id === updatedWidget.id) {
        return updatedWidget
      }
      return w
    })

    setWidgets(updatedWidgets)
    setIsWidgetConfigModalVisible(false)
    message.success("Widget configuration updated")
  }

  const handleDeleteWidget = (widgetId) => {
    Modal.confirm({
      title: "Are you sure you want to delete this widget?",
      content: "This action cannot be undone.",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",
      onOk() {
        // Remove widget from widgets array
        setWidgets(widgets.filter((w) => w.id !== widgetId))

        // Remove widget from layout
        setLayouts({
          lg: layouts.lg.filter((item) => item.i !== widgetId),
          md: layouts.md.filter((item) => item.i !== widgetId),
          sm: layouts.sm.filter((item) => item.i !== widgetId),
          xs: layouts.xs.filter((item) => item.i !== widgetId),
        })

        message.success("Widget deleted")
      },
    })
  }

  const handleDuplicateWidget = (widget) => {
    const newWidgetId = Date.now().toString()
    const newWidget = {
      ...widget,
      id: newWidgetId,
      title: `${widget.title} (Copy)`,
    }

    // Add duplicated widget to widgets array
    setWidgets([...widgets, newWidget])

    // Find the layout of the original widget
    const originalLayout = layouts.lg.find((item) => item.i === widget.id)

    if (originalLayout) {
      // Create a new layout for the duplicated widget
      const newLayout = {
        ...originalLayout,
        i: newWidgetId,
        x: (originalLayout.x + 1) % 12, // Position it next to the original
        y: originalLayout.y + 1, // Position it below the original
      }

      // Update layouts for all breakpoints
      setLayouts({
        lg: [...layouts.lg, newLayout],
        md: [...layouts.md, { ...newLayout, w: Math.min(newLayout.w, 8) }],
        sm: [...layouts.sm, { ...newLayout, w: Math.min(newLayout.w * 2, 12), x: 0 }],
        xs: [...layouts.xs, { ...newLayout, w: 12, x: 0 }],
      })
    }

    message.success("Widget duplicated")
  }

  const handleLayoutChange = (layout, allLayouts) => {
    setLayouts(allLayouts)
  }

  const handleTimeWindowChange = (newTimeWindow) => {
    setTimeWindow(newTimeWindow)
    setIsTimeWindowVisible(false)
  }

  const handleAssignCustomers = () => {
    setIsAssignCustomerModalVisible(true)
  }

  const handleAssignCustomersSave = (selectedCustomers) => {
    setAssignedCustomers(selectedCustomers)
    setIsAssignCustomerModalVisible(false)
    message.success("Dashboard assigned to customers")
  }

  // const handleSave = () => {
  //   // Create dashboard state object
  //   const dashboardState = {
  //     id: id || Date.now().toString(),
  //     title: dashboardTitle,
  //     widgets: widgets,
  //     layouts: layouts,
  //     settings: dashboardSettings,
  //     assignedCustomers: assignedCustomers,
  //     timewindow: timeWindow,
  //     createdTime: new Date().toISOString(),
  //     version: "1.0.0",
  //   }

  //   // Convert to JSON string
  //   const dashboardJson = JSON.stringify(dashboardState, null, 2)

  //   // Create a blob and save it as a file
  //   const blob = new Blob([dashboardJson], { type: "application/json" })
  //   saveAs(blob, `${dashboardTitle.replace(/\s+/g, "_").toLowerCase()}_dashboard.json`)

  //   message.success("Dashboard saved successfully")
  // }
  const handleSave = async () => {
    const dashboardState = {
      title: dashboardTitle,
      widgets: JSON.stringify(widgets),
      layouts: JSON.stringify(layouts),
      settings: JSON.stringify(dashboardSettings),
      assignedCustomers,
      timewindow: JSON.stringify(timeWindow),
      version: "1.0.0",
    }
  
    try {
      let result
      if (id && id !== "new") {
        result = await updateDashboard(id, dashboardState)
        message.success("Dashboard updated")
      } else {
        result = await createDashboard(dashboardState)
        message.success("Dashboard created")
        navigate(`/dashboards/${result.id}`)
      }
    } catch (err) {
      console.error(err)
      message.error("Failed to save dashboard")
    }
  }
  const handleImportDashboard = (file) => {
    const reader = new FileReader()

    reader.onload = (e) => {
      try {
        const dashboardData = JSON.parse(e.target.result)

        // Validate the dashboard data
        if (!dashboardData.widgets || !dashboardData.layouts) {
          throw new Error("Invalid dashboard file format")
        }

        // Set dashboard state from imported file
        setDashboardTitle(dashboardData.title || "Imported Dashboard")
        setWidgets(dashboardData.widgets || [])
        setLayouts(dashboardData.layouts || { lg: [], md: [], sm: [], xs: [] })
        setDashboardSettings(dashboardData.settings || dashboardSettings)
        setAssignedCustomers(dashboardData.assignedCustomers || [])
        setTimeWindow(dashboardData.timewindow || timeWindow)

        setIsImportModalVisible(false)
        message.success("Dashboard imported successfully")
      } catch (error) {
        console.error("Error importing dashboard:", error)
        message.error("Failed to import dashboard. Invalid file format.")
      }
    }

    reader.readAsText(file)
  }

  const handleCancel = () => {
    navigate("/dashboards")
  }

  const timeWindowMenu = (
    <Menu>
      <Menu.Item
        key="realtime_15_minutes"
        onClick={() =>
          handleTimeWindowChange({ displayValue: "Last 15 minutes", value: "15_minutes", type: "REALTIME" })
        }
      >
        Last 15 minutes
      </Menu.Item>
      <Menu.Item
        key="realtime_30_minutes"
        onClick={() =>
          handleTimeWindowChange({ displayValue: "Last 30 minutes", value: "30_minutes", type: "REALTIME" })
        }
      >
        Last 30 minutes
      </Menu.Item>
      <Menu.Item
        key="realtime_1_hour"
        onClick={() => handleTimeWindowChange({ displayValue: "Last 1 hour", value: "1_hour", type: "REALTIME" })}
      >
        Last 1 hour
      </Menu.Item>
      <Menu.Item
        key="realtime_6_hours"
        onClick={() => handleTimeWindowChange({ displayValue: "Last 6 hours", value: "6_hours", type: "REALTIME" })}
      >
        Last 6 hours
      </Menu.Item>
      <Menu.Item
        key="realtime_1_day"
        onClick={() => handleTimeWindowChange({ displayValue: "Last 1 day", value: "1_day", type: "REALTIME" })}
      >
        Last 1 day
      </Menu.Item>
      <Menu.Item key="custom" onClick={() => setIsTimeWindowVisible(true)}>
        Custom...
      </Menu.Item>
    </Menu>
  )

  // Generate mock data for widgets based on time window
  const generateMockData = (dataKeys, timeWindow) => {
    if (!dataKeys || dataKeys.length === 0) return []

    const now = new Date()
    const data = []
    let timeRange = 900000 // 15 minutes in milliseconds (default)

    // Set time range based on selected time window
    switch (timeWindow.value) {
      case "30_minutes":
        timeRange = 1800000
        break
      case "1_hour":
        timeRange = 3600000
        break
      case "6_hours":
        timeRange = 21600000
        break
      case "1_day":
        timeRange = 86400000
        break
      default:
        timeRange = 900000
    }

    // Number of data points to generate
    const numPoints = 100
    const interval = timeRange / numPoints

    for (let i = 0; i < numPoints; i++) {
      const time = new Date(now.getTime() - (numPoints - i) * interval)
      const point = { time: time.toISOString() }

      // Generate values for each data key
      dataKeys.forEach((key) => {
        if (key === "temperature") {
          // Temperature between 20-30°C with some randomness
          point[key] = 25 + 5 * Math.sin((i / numPoints) * Math.PI * 2) + Math.random() * 2 - 1
        } else if (key === "humidity") {
          // Humidity between 40-60% with some randomness
          point[key] = 50 + 10 * Math.cos((i / numPoints) * Math.PI * 2) + Math.random() * 5 - 2.5
        } else if (key === "batteryLevel") {
          // Battery level decreasing from 100% to 80%
          point[key] = 100 - (20 * i) / numPoints - Math.random() * 2
        } else if (key === "signalStrength") {
          // Signal strength between 60-90% with some randomness
          point[key] = 75 + 15 * Math.sin((i / numPoints) * Math.PI * 4) + Math.random() * 5 - 2.5
        } else if (key === "status") {
          // Status is either "Online" or "Offline"
          point[key] = Math.random() > 0.1 ? "Online" : "Offline"
        } else {
          // Generic random value between 0-100
          point[key] = Math.random() * 100
        }
      })

      data.push(point)
    }

    return data
  }

  return (
    <Layout style={{ height: "calc(100vh - 64px)" }}>
      <Header
        style={{
          background: "#fff",
          padding: "0 16px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          height: "64px",
          boxShadow: "0 1px 4px rgba(0,21,41,.08)",
        }}
      >
        <Input
          placeholder="Dashboard title"
          style={{ width: isMobile ? 150 : 300 }}
          value={dashboardTitle}
          onChange={(e) => setDashboardTitle(e.target.value)}
        />
        <Space wrap={isMobile}>
          <Button icon={<PlusOutlined />} onClick={() => setIsWidgetLibraryVisible(true)}>
            {!isMobile && "Add widget"}
          </Button>
          <Dropdown overlay={timeWindowMenu} trigger={["click"]}>
            <Button icon={<ClockCircleOutlined />}>
              {!isMobile && timeWindow.displayValue} {isMobile && <DownOutlined />}
            </Button>
          </Dropdown>
          <Button icon={<SettingOutlined />} onClick={() => setIsSettingsVisible(true)}>
            {!isMobile && "Settings"}
          </Button>
          {!isMobile && (
            <>
              <Button icon={<LinkOutlined />} onClick={() => setIsAliasesModalVisible(true)}>
                Aliases
              </Button>
              <Button icon={<FilterOutlined />}>Filters</Button>
              <Button icon={<HistoryOutlined />}>Versions</Button>
            </>
          )}
          {!isTablet && (
            <Button icon={<TeamOutlined />} onClick={handleAssignCustomers}>
              Assign
            </Button>
          )}
          <Button icon={<UploadOutlined />} onClick={() => setIsImportModalVisible(true)}>
            {!isMobile && "Import"}
          </Button>
          <Button icon={<DownloadOutlined />} onClick={handleSave}>
            {!isMobile && "Export"}
          </Button>
          <Button icon={<CloseOutlined />} onClick={handleCancel}>
            {!isMobile && "Cancel"}
          </Button>
          <Button icon={<SaveOutlined />} type="primary" onClick={handleSave}>
            {!isMobile && "Save"}
          </Button>
          {!isMobile && <Button icon={<FullscreenOutlined />} />}
        </Space>
      </Header>

      <Content style={{ padding: isMobile ? "12px" : "24px", background: "#f0f2f5", overflow: "auto" }}>
        <div
          style={{
            minHeight: "100%",
            background: "#fff",
            padding: isMobile ? "12px" : "24px",
            borderRadius: "4px",
            boxShadow: "0 1px 4px rgba(0,21,41,.08)",
          }}
        >
          {widgets.length === 0 ? (
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                height: "400px",
                color: "#999",
              }}
            >
              <div style={{ fontSize: "64px", marginBottom: "16px" }}>📊</div>
              <Typography.Title level={4}>No widgets added yet</Typography.Title>
              <Button
                type="primary"
                icon={<PlusOutlined />}
                onClick={() => setIsWidgetLibraryVisible(true)}
                style={{ marginTop: "16px" }}
              >
                Add your first widget
              </Button>
            </div>
          ) : (
            <ResponsiveGridLayout
              className="layout"
              layouts={layouts}
              breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
              cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
              rowHeight={100}
              onLayoutChange={handleLayoutChange}
              isDraggable={true}
              isResizable={true}
              margin={[10, 10]}
              draggableHandle=".widget-drag-handle" // <-- ONLY allow drag from this class

              // draggableCancel=".no-drag"
            >
              {widgets.map((widget) => (
                  <div key={widget.id} className="widget-container" style={{ position: "relative", border: "1px solid #eee", borderRadius: 6, overflow: "hidden" }}>
                    
                    {/* Floating Control Buttons */}
                    <div
                      style={{
                        position: "absolute",
                        top: 4,
                        right: 4,
                        zIndex: 10,
                        display: "flex",
                        gap: 4,
                        background: "rgba(255,255,255,0.9)",
                        borderRadius: 4,
                        padding: 2,
                        boxShadow: "0 0 4px rgba(0,0,0,0.1)"
                      }}
                    >
                      <Button
                        type="text"
                        size="small"
                        icon={<EditOutlined />}
                        onClick={(e) => {
                          e.stopPropagation()
                          handleWidgetSettings(widget)
                        }}
                      />
                      <Button
                        type="text"
                        size="small"
                        icon={<CopyOutlined />}
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDuplicateWidget(widget)
                        }}
                      />
                      <Button
                        type="text"
                        size="small"
                        danger
                        icon={<DeleteOutlined />}
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDeleteWidget(widget.id)
                        }}
                      />
                    </div>

                    {/* Drag Handle Header */}
                    <div
                      className="widget-drag-handle"
                      style={{
                        cursor: "move",
                        padding: "6px 12px",
                        fontWeight: 500,
                        fontSize: 14,
                        background: "#f5f5f5",
                        borderBottom: "1px solid #e0e0e0",
                        color: "#333",
                      }}
                    >
                      {widget.title}
                    </div>

                    {/* Widget Body */}
                    <div style={{ padding: 8 }}>
                      <WidgetRenderer
                        widget={widget}
                        config={{
                          ...widget.config,
                          data: generateMockData(widget.config?.dataSource?.dataKeys, timeWindow),
                          timeWindow: timeWindow,
                        }}
                      />
                    </div>
                  </div>
                ))}


            </ResponsiveGridLayout>
          )}
        </div>
      </Content>

      <WidgetLibrary
        visible={isWidgetLibraryVisible}
        onClose={() => setIsWidgetLibraryVisible(false)}
        onSelect={handleAddWidget}
      />

      <TimeWindowSettings
        visible={isTimeWindowVisible}
        onClose={() => setIsTimeWindowVisible(false)}
        onSave={handleTimeWindowChange}
        initialValue={timeWindow}
      />

      <DashboardSettings visible={isSettingsVisible} onClose={() => setIsSettingsVisible(false)} />

      <ManageLayoutsModal visible={isLayoutsModalVisible} onClose={() => setIsLayoutsModalVisible(false)} />

      <ManageStatesModal visible={isStatesModalVisible} onClose={() => setIsStatesModalVisible(false)} />

      <EntityAliasesModal visible={isAliasesModalVisible} onClose={() => setIsAliasesModalVisible(false)} />

      <WidgetConfigModal
        visible={isWidgetConfigModalVisible}
        onCancel={() => setIsWidgetConfigModalVisible(false)}
        onSave={handleWidgetConfigSave}
        widget={selectedWidget}
        devices={devices}
      />

      {/* Import Dashboard Modal */}
      <Modal
        title="Import Dashboard"
        open={isImportModalVisible}
        onCancel={() => setIsImportModalVisible(false)}
        footer={null}
      >
        <div style={{ padding: "20px 0" }}>
          <input
            type="file"
            accept=".json"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleImportDashboard(e.target.files[0])
              }
            }}
            style={{ marginBottom: "20px" }}
          />
          <Typography.Paragraph>
            Select a dashboard JSON file to import. The file should contain a valid dashboard configuration.
          </Typography.Paragraph>
          <Typography.Text type="secondary">
            Note: Importing a dashboard will replace your current dashboard configuration.
          </Typography.Text>
        </div>
      </Modal>

      {/* Assign Customer Modal */}
      <Modal
        title="Assign Dashboard to Customers"
        open={isAssignCustomerModalVisible}
        onCancel={() => setIsAssignCustomerModalVisible(false)}
        onOk={() => {
          form.validateFields().then((values) => {
            handleAssignCustomersSave(values.customers)
          })
        }}
      >
        <Form form={form} layout="vertical" initialValues={{ customers: assignedCustomers }}>
          <Form.Item
            name="customers"
            label="Select Customers"
            rules={[{ required: false, message: "Please select at least one customer" }]}
          >
            <Select mode="multiple" placeholder="Select customers" style={{ width: "100%" }} optionLabelProp="label">
              {customers.map((customer) => (
                <Select.Option key={customer.id} value={customer.id} label={customer.name}>
                  {customer.name}
                </Select.Option>
              ))}
            </Select>
          </Form.Item>
          <Typography.Paragraph>
            Assigned customers will be able to view this dashboard in their customer portal.
          </Typography.Paragraph>
        </Form>
      </Modal>
    </Layout>
  )
}

export default DashboardEditor
