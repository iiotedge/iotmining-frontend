"use client"

import { useState } from "react"
import { Card, Table, Button, Space, Typography, Modal, Form, Tabs } from "antd"
import {
  PlusOutlined,
  ReloadOutlined,
  SearchOutlined,
  UserOutlined,
  DashboardOutlined,
  AppstoreOutlined,
  CloudServerOutlined,
  DeleteOutlined,
} from "@ant-design/icons"
import CustomerDetailsDrawer from "../components/customer/CustomerDetailsDrawer"
import AddCustomerModal from "../components/customer/AddCustomerModal"

const { Title } = Typography
const { TabPane } = Tabs

const CustomersPage = () => {
  const [selectedRowKeys, setSelectedRowKeys] = useState([])
  const [isAddModalVisible, setIsAddModalVisible] = useState(false)
  const [isDetailsDrawerVisible, setIsDetailsDrawerVisible] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState(null)
  const [form] = Form.useForm()

  const [customers, setCustomers] = useState([
    {
      key: "1",
      createdTime: "2025-03-05 13:18:42",
      title: "Public",
      email: "",
      country: "",
      city: "",
    },
    {
      key: "2",
      createdTime: "2025-01-27 15:01:20",
      title: "Device Claiming Customer",
      email: "",
      country: "Germany",
      city: "Berlin",
    },
    {
      key: "3",
      createdTime: "2025-01-27 15:01:20",
      title: "Demo Customer",
      email: "",
      country: "Germany",
      city: "Berlin",
    },
    {
      key: "4",
      createdTime: "2025-01-27 15:01:18",
      title: "Customer C",
      email: "",
      country: "",
      city: "",
    },
    {
      key: "5",
      createdTime: "2025-01-27 15:01:18",
      title: "Customer B",
      email: "",
      country: "",
      city: "",
    },
    {
      key: "6",
      createdTime: "2025-01-27 15:01:18",
      title: "Customer A",
      email: "",
      country: "",
      city: "",
    },
  ])

  const columns = [
    {
      title: "",
      dataIndex: "select",
      width: 50,
      render: () => <input type="checkbox" />,
    },
    {
      title: "Created time",
      dataIndex: "createdTime",
      key: "createdTime",
      sorter: (a, b) => a.createdTime.localeCompare(b.createdTime),
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      render: (text, record) => <a onClick={() => handleCustomerClick(record)}>{text}</a>,
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Country",
      dataIndex: "country",
      key: "country",
    },
    {
      title: "City",
      dataIndex: "city",
      key: "city",
    },
    {
      title: "",
      key: "actions",
      render: (_, record) => (
        <Space>
          <Button type="text" icon={<UserOutlined />} title="Manage users" />
          <Button type="text" icon={<AppstoreOutlined />} title="Manage assets" />
          <Button type="text" icon={<DashboardOutlined />} title="Manage dashboards" />
          <Button type="text" icon={<CloudServerOutlined />} title="Manage edge instances" />
          <Button
            type="text"
            icon={<DeleteOutlined />}
            title="Delete customer"
            onClick={() => showDeleteConfirm(record)}
          />
        </Space>
      ),
    },
  ]

  const handleCustomerClick = (customer) => {
    setSelectedCustomer(customer)
    setIsDetailsDrawerVisible(true)
  }

  const showAddModal = () => {
    setIsAddModalVisible(true)
  }

  const handleAddCancel = () => {
    setIsAddModalVisible(false)
    form.resetFields()
  }

  const handleAddSubmit = (values) => {
    const newCustomer = {
      key: String(customers.length + 1),
      createdTime: new Date().toISOString().replace("T", " ").substring(0, 19),
      title: values.title,
      email: values.email || "",
      country: values.country || "",
      city: values.city || "",
    }

    setCustomers([...customers, newCustomer])
    setIsAddModalVisible(false)
    form.resetFields()
  }

  const handleDetailsDrawerClose = () => {
    setIsDetailsDrawerVisible(false)
    setSelectedCustomer(null)
  }

  const showDeleteConfirm = (customer) => {
    Modal.confirm({
      title: "Are you sure you want to delete this customer?",
      content: `Customer "${customer.title}" will be deleted.`,
      okText: "Yes",
      okType: "danger",
      cancelText: "No",
      onOk() {
        setCustomers(customers.filter((c) => c.key !== customer.key))
      },
    })
  }

  const onSelectChange = (newSelectedRowKeys) => {
    setSelectedRowKeys(newSelectedRowKeys)
  }

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  }

  return (
    <>
      <Card
        title={<Title level={4}>Customers</Title>}
        extra={
          <Space>
            <Button icon={<PlusOutlined />} type="primary" onClick={showAddModal}>
              Add customer
            </Button>
            <Button icon={<ReloadOutlined />} />
            <Button icon={<SearchOutlined />} />
          </Space>
        }
      >
        <Table
          rowSelection={rowSelection}
          columns={columns}
          dataSource={customers}
          pagination={{
            total: customers.length,
            pageSize: 10,
            showSizeChanger: true,
            showTotal: (total, range) => `${range[0]}-${range[1]} of ${total}`,
          }}
        />
      </Card>

      <AddCustomerModal visible={isAddModalVisible} onCancel={handleAddCancel} onAdd={handleAddSubmit} />

      <CustomerDetailsDrawer
        visible={isDetailsDrawerVisible}
        onClose={handleDetailsDrawerClose}
        customer={selectedCustomer}
      />
    </>
  )
}

export default CustomersPage

