"use client"

import React, { useState, useEffect } from "react"
import {
  Form,
  Input,
  Button,
  Checkbox,
  DatePicker,
  Select,
  Divider,
  Typography,
  Space,
  message,
} from "antd"
import {
  UserOutlined,
  LockOutlined,
  MailOutlined,
  PhoneOutlined,
  GoogleOutlined,
  GithubOutlined,
  FacebookOutlined,
} from "@ant-design/icons"
import axios from "axios"
import dayjs from "dayjs"

const { Option } = Select

const SignupForm = ({ onSuccess }) => {
  const [loading, setLoading] = useState(false)
  const [form] = Form.useForm()
  const [isMobile, setIsMobile] = useState(false)

  const BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8096/api/v1"

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 575)
    }
    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => {
      window.removeEventListener("resize", checkMobile)
    }
  }, [])

  const handleSubmit = async (values) => {
    setLoading(true)
    try {
      const payload = {
        firstName: values.firstName,
        lastName: values.lastName,
        gender: values.gender,
        dateOfBirth: values.dateOfBirth ? values.dateOfBirth.format("YYYY-MM-DD") : null,
        email: values.email,
        password: values.password,
        phoneNumber: values.phoneNumber,
        roles: values.roles,
        username: values.username,
      }
      console.log(payload);
      await axios.post(`${BASE_URL}/auth/register`, payload)

      message.success("Account created successfully! Please log in.")
      onSuccess()
    } catch (error) {
      console.error("Signup error:", error)
      const errorMsg = error?.response?.data?.message || "Registration failed. Please try again."
      message.error(errorMsg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="signup-form-container">
      <Form
        form={form}
        name="signup"
        initialValues={{ agreement: false }}
        onFinish={handleSubmit}
        layout="vertical"
        size={isMobile ? "middle" : "large"}
        className="auth-form"
      >
        <Form.Item name="firstName" rules={[{ required: true, message: "Enter your first name" }]}>
          <Input prefix={<UserOutlined />} placeholder="First Name" />
        </Form.Item>

        <Form.Item name="lastName" rules={[{ required: true, message: "Enter your last name" }]}>
          <Input prefix={<UserOutlined />} placeholder="Last Name" />
        </Form.Item>

        <Form.Item name="username" rules={[{ required: true, message: "Choose a username" }]}>
          <Input prefix={<UserOutlined />} placeholder="Username" />
        </Form.Item>

        <Form.Item name="gender" rules={[{ required: true, message: "Select gender" }]}>
          <Select placeholder="Gender">
            <Option value="MALE">Male</Option>
            <Option value="FEMALE">Female</Option>
            <Option value="OTHER">Other</Option>
          </Select>
        </Form.Item>

        <Form.Item name="dateOfBirth" rules={[{ required: true, message: "Select birth date" }]}>
          <DatePicker style={{ width: "100%" }} placeholder="Date of Birth" />
        </Form.Item>

        <Form.Item
          name="email"
          rules={[
            { required: true, message: "Enter your email" },
            { type: "email", message: "Enter a valid email" },
          ]}
        >
          <Input prefix={<MailOutlined />} placeholder="Email" />
        </Form.Item>

        <Form.Item name="phoneNumber" rules={[{ required: true, message: "Enter phone number" }]}>
          <Input prefix={<PhoneOutlined />} placeholder="Phone Number" />
        </Form.Item>

        <Form.Item name="roles" rules={[{ required: true, message: "Select at least one role" }]}>
          <Select mode="multiple" placeholder="Select roles">
            <Option value="ROLE_USER">User</Option>
            <Option value="ROLE_ADMIN">Admin</Option>
            <Option value="ROLE_SUPER_ADMIN">Manager</Option>
          </Select>
        </Form.Item>

        <Form.Item
          name="password"
          rules={[
            { required: true, message: "Enter a password" },
            { min: 8, message: "Password must be at least 8 characters" },
          ]}
          hasFeedback
        >
          <Input.Password prefix={<LockOutlined />} placeholder="Password" />
        </Form.Item>

        <Form.Item
          name="confirmPassword"
          dependencies={["password"]}
          hasFeedback
          rules={[
            { required: true, message: "Confirm your password" },
            ({ getFieldValue }) => ({
              validator(_, value) {
                if (!value || getFieldValue("password") === value) {
                  return Promise.resolve()
                }
                return Promise.reject(new Error("Passwords do not match"))
              },
            }),
          ]}
        >
          <Input.Password prefix={<LockOutlined />} placeholder="Confirm Password" />
        </Form.Item>

        <Form.Item
          name="agreement"
          valuePropName="checked"
          rules={[
            {
              validator: (_, value) =>
                value ? Promise.resolve() : Promise.reject(new Error("Accept terms to continue")),
            },
          ]}
        >
          <Checkbox>
            I agree to the <a href="/terms">Terms of Service</a> and{" "}
            <a href="/privacy">Privacy Policy</a>
          </Checkbox>
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" className="auth-button" loading={loading} block>
            Sign Up
          </Button>
        </Form.Item>

        <Divider plain>
          <Typography.Text type="secondary">Or sign up with</Typography.Text>
        </Divider>

        <div className="social-login">
          <Space size={isMobile ? "small" : "middle"}>
            <Button icon={<GoogleOutlined />} shape="circle" size="large" />
            <Button icon={<GithubOutlined />} shape="circle" size="large" />
            <Button icon={<FacebookOutlined />} shape="circle" size="large" />
          </Space>
        </div>
      </Form>
    </div>
  )
}

export default SignupForm
