"use client"

import React, { useState, useEffect } from "react"
import { Form, Input, Button, message } from "antd"
import { UserOutlined, LockOutlined } from "@ant-design/icons"
import { useNavigate } from "react-router-dom"
import { jwtDecode } from "jwt-decode"
import axios from "axios"
import { getRedirectPathFromRole } from "../../utils/roleRedirect"

const LoginForm = ({ onSuccess }) => {
  const [loading, setLoading] = useState(false)
  const [form] = Form.useForm()
  const [isMobile, setIsMobile] = useState(false)
  const navigate = useNavigate()

  const BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8096/api/v1"

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 575)
    }
    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => {
      window.removeEventListener("resize", checkMobile)
    }
  }, [])

  const handleLogin = async (values) => {
    setLoading(true)
    try {
      const response = await axios.post(`${BASE_URL}/auth/login`, {
        username: values.email,
        password: values.password,
      })

      const token = response.data?.data?.accessToken
      if (!token) throw new Error("No token returned from server")

      localStorage.setItem("token", token)
      
      message.success("Login successful!")

      // Redirect user based on decoded token roles
      navigate(getRedirectPathFromRole(token))

      onSuccess?.()

    } catch (error) {
      console.error("Login error:", error)
      const msg = error?.response?.data?.message || "Login failed. Check credentials."
      message.error(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Form
      form={form}
      name="login"
      onFinish={handleLogin}
      layout="vertical"
      size={isMobile ? "middle" : "large"}
      className="auth-form"
    >
      <Form.Item name="email" rules={[{ required: true, message: "Please enter your email" }]}>
        <Input prefix={<UserOutlined />} placeholder="Email" className="auth-input" />
      </Form.Item>
      <Form.Item name="password" rules={[{ required: true, message: "Please enter your password" }]}>
        <Input.Password prefix={<LockOutlined />} placeholder="Password" className="auth-input" />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit" className="auth-button" loading={loading} block>
          Log In
        </Button>
      </Form.Item>
    </Form>
  )
}

export default LoginForm
