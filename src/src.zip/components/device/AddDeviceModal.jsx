import React, { useState, useContext } from 'react';
import { X, Save, AlertCircle } from 'lucide-react';
import { ThemeContext } from '../theme/ThemeProvider';

const AddDeviceModal = ({ isOpen, onClose, onDeviceAdded }) => {
  const { theme } = useContext(ThemeContext);
  const [deviceName, setDeviceName] = useState('');
  const [deviceType, setDeviceType] = useState('default');
  const [label, setLabel] = useState('');
  const [description, setDescription] = useState('');
  const [isGateway, setIsGateway] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const deviceTypes = [
    { value: 'default', label: 'Default' },
    { value: 'thermostat', label: 'Thermostat' },
    { value: 'camera', label: 'Camera' },
    { value: 'sensor', label: 'Sensor' },
    { value: 'actuator', label: 'Actuator' },
    { value: 'gateway', label: 'Gateway' }
  ];

  const resetForm = () => {
    setDeviceName('');
    setDeviceType('default');
    setLabel('');
    setDescription('');
    setIsGateway(false);
    setError('');
    setIsLoading(false);
    setIsSuccess(false);
  };

  const validateForm = () => {
    if (!deviceName.trim()) {
      setError('Device name is required');
      return false;
    }
    
    // Check for special characters except underscore and hyphen
    const nameRegex = /^[a-zA-Z0-9_-]+$/;
    if (!nameRegex.test(deviceName)) {
      setError('Device name can only contain letters, numbers, underscores, and hyphens');
      return false;
    }
    
    setError('');
    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      try {
        // Create a new device object
        const newDevice = {
          id: `device_${Date.now()}`,
          name: deviceName,
          type: deviceType,
          label: label || deviceName,
          description,
          isGateway,
          createdTime: new Date().toISOString(),
          active: true
        };
        
        setIsLoading(false);
        setIsSuccess(true);
        
        // Notify parent component
        if (onDeviceAdded) {
          onDeviceAdded(newDevice);
        }
        
        // Reset form after successful submission
        setTimeout(() => {
          resetForm();
          onClose();
        }, 1500);
      } catch (err) {
        setIsLoading(false);
        setError('Failed to create device. Please try again.');
        console.error('Error creating device:', err);
      }
    }, 1000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div 
        className={`w-full max-w-lg rounded-lg shadow-xl ${
          theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'
        }`}
      >
        <div className={`flex items-center justify-between p-4 border-b ${
          theme === 'dark' ? 'border-gray-700' : 'border-gray-200'
        }`}>
          <h2 className="text-xl font-semibold">Add Device</h2>
          <button 
            onClick={onClose}
            className={`p-1 rounded-full transition-colors ${
              theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
            }`}
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-4">
          {error && (
            <div className={`mb-4 p-3 rounded-md flex items-start ${
              theme === 'dark' ? 'bg-red-900/30 text-red-300' : 'bg-red-50 text-red-600'
            }`}>
              <AlertCircle size={18} className="mr-2 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
          
          {isSuccess && (
            <div className={`mb-4 p-3 rounded-md ${
              theme === 'dark' ? 'bg-green-900/30 text-green-300' : 'bg-green-50 text-green-600'
            }`}>
              Device created successfully!
            </div>
          )}
          
          <div className="mb-4">
            <label className="block mb-2 text-sm font-medium">
              Device Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={deviceName}
              onChange={(e) => setDeviceName(e.target.value)}
              className={`w-full p-2 border rounded-md ${
                theme === 'dark' 
                  ? 'bg-gray-700 border-gray-600 focus:border-blue-500' 
                  : 'bg-white border-gray-300 focus:border-blue-500'
              } focus:outline-none focus:ring-1 focus:ring-blue-500`}
              placeholder="Enter device name"
              required
            />
            <p className={`mt-1 text-xs ${
              theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
            }`}>
              Use a unique identifier (letters, numbers, underscores, hyphens only)
            </p>
          </div>
          
          <div className="mb-4">
            <label className="block mb-2 text-sm font-medium">
              Device Type
            </label>
            <select
              value={deviceType}
              onChange={(e) => setDeviceType(e.target.value)}
              className={`w-full p-2 border rounded-md ${
                theme === 'dark' 
                  ? 'bg-gray-700 border-gray-600 focus:border-blue-500' 
                  : 'bg-white border-gray-300 focus:border-blue-500'
              } focus:outline-none focus:ring-1 focus:ring-blue-500`}
            >
              {deviceTypes.map(type => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>
          
          <div className="mb-4">
            <label className="block mb-2 text-sm font-medium">
              Label
            </label>
            <input
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              className={`w-full p-2 border rounded-md ${
                theme === 'dark' 
                  ? 'bg-gray-700 border-gray-600 focus:border-blue-500' 
                  : 'bg-white border-gray-300 focus:border-blue-500'
              } focus:outline-none focus:ring-1 focus:ring-blue-500`}
              placeholder="Enter device label"
            />
          </div>
          
          <div className="mb-4">
            <label className="block mb-2 text-sm font-medium">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={`w-full p-2 border rounded-md ${
                theme === 'dark' 
                  ? 'bg-gray-700 border-gray-600 focus:border-blue-500' 
                  : 'bg-white border-gray-300 focus:border-blue-500'
              } focus:outline-none focus:ring-1 focus:ring-blue-500`}
              placeholder="Enter device description"
              rows={3}
            />
          </div>
          
          <div className="mb-4">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={isGateway}
                onChange={(e) => setIsGateway(e.target.checked)}
                className={`mr-2 rounded ${
                  theme === 'dark' ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-300'
                }`}
              />
              <span className="text-sm font-medium">This device is a gateway</span>
            </label>
          </div>
          
          <div className="flex justify-end space-x-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2 rounded-md transition-colors ${
                theme === 'dark' 
                  ? 'bg-gray-700 hover:bg-gray-600' 
                  : 'bg-gray-200 hover:bg-gray-300'
              }`}
              disabled={isLoading}
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-4 py-2 rounded-md flex items-center transition-colors ${
                isLoading 
                  ? (theme === 'dark' ? 'bg-blue-700' : 'bg-blue-400') 
                  : (theme === 'dark' ? 'bg-blue-600 hover:bg-blue-500' : 'bg-blue-500 hover:bg-blue-600')
              } text-white`}
              disabled={isLoading || isSuccess}
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Processing...
                </>
              ) : (
                <>
                  <Save size={18} className="mr-2" />
                  Add Device
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddDeviceModal;
