"use client"
import { Modal, Form, Select, Input } from "antd"

const { Option } = Select

const NotificationSendModal = ({ visible, onCancel, onSend, templates, recipients }) => {
  const [form] = Form.useForm()

  const handleTemplateChange = (templateId) => {
    const template = templates.find((t) => t.id === templateId)

    if (template) {
      form.setFieldsValue({
        subject: template.subject || "",
        body: template.body || "",
      })
    }
  }

  const handleSend = () => {
    form
      .validateFields()
      .then((values) => {
        onSend({
          templateId: values.templateId,
          recipientId: values.recipientId,
          subject: values.subject,
          body: values.body,
        })
        form.resetFields()
      })
      .catch((error) => {
        console.error("Validation failed:", error)
      })
  }

  return (
    <Modal title="Send notification" open={visible} onCancel={onCancel} onOk={handleSend} okText="Send" width={700}>
      <Form form={form} layout="vertical">
        <Form.Item
          name="templateId"
          label="Template"
          rules={[{ required: true, message: "Please select a template!" }]}
        >
          <Select placeholder="Select template" onChange={handleTemplateChange}>
            {templates.map((template) => (
              <Option key={template.id} value={template.id}>
                {template.name}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          name="recipientId"
          label="Recipients"
          rules={[{ required: true, message: "Please select recipients!" }]}
        >
          <Select placeholder="Select recipients" mode="multiple">
            {recipients.map((recipient) => (
              <Option key={recipient.id} value={recipient.id}>
                {recipient.name}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item name="subject" label="Subject" rules={[{ required: true, message: "Please input the subject!" }]}>
          <Input placeholder="Enter subject" />
        </Form.Item>

        <Form.Item name="body" label="Body" rules={[{ required: true, message: "Please input the body!" }]}>
          <Input.TextArea rows={6} placeholder="Enter notification body" />
        </Form.Item>
      </Form>
    </Modal>
  )
}

export default NotificationSendModal
