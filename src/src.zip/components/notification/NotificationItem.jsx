"use client"
import { List, Avatar, Button, Typography, Space } from "antd"
import { InfoCircleOutlined } from "@ant-design/icons"
import { formatDistanceToNow } from "date-fns"

const { Text, Paragraph } = Typography

const NotificationItem = ({ notification, onClick }) => {
  const getIcon = () => {
    switch (notification.type) {
      case "DEVICE_ADDED":
        return <InfoCircleOutlined style={{ color: "#1890ff" }} />
      case "ALARM":
        return <InfoCircleOutlined style={{ color: "#f5222d" }} />
      default:
        return <InfoCircleOutlined />
    }
  }

  const getTimeAgo = (timestamp) => {
    try {
      return formatDistanceToNow(new Date(timestamp), { addSuffix: false })
    } catch (e) {
      return "unknown time"
    }
  }

  const renderActionButton = () => {
    switch (notification.type) {
      case "DEVICE_ADDED":
        return (
          <Button
            size="small"
            type="primary"
            onClick={(e) => {
              e.stopPropagation()
              window.location.href = `/devices/${notification.entityId}`
            }}
          >
            Go to device
          </Button>
        )
      default:
        return null
    }
  }

  return (
    <List.Item
      className={`notification-item ${notification.read ? "" : "unread"}`}
      onClick={() => onClick(notification)}
    >
      <List.Item.Meta
        avatar={<Avatar icon={getIcon()} />}
        title={<Text strong>{notification.title}</Text>}
        description={
          <Space direction="vertical" size={2} style={{ width: "100%" }}>
            <Paragraph ellipsis={{ rows: 2 }}>{notification.message}</Paragraph>
            <Text type="secondary" style={{ fontSize: "12px" }}>
              {getTimeAgo(notification.createdTime)}
            </Text>
            {renderActionButton()}
          </Space>
        }
      />
      {!notification.read && (
        <div
          className="notification-unread-indicator"
          style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: "#1890ff" }}
        />
      )}
    </List.Item>
  )
}

export default NotificationItem
