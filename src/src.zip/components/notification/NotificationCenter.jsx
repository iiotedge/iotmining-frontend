"use client"

import { useState, useEffect } from "react"
import { Tabs, Button, Table, Space, Typography } from "antd"
import {
  SearchOutlined,
  ReloadOutlined,
  SendOutlined,
  CheckCircleOutlined,
  DeleteOutlined,
  CopyOutlined,
  EditOutlined,
  PlusOutlined,
} from "@ant-design/icons"
import notificationService from "../../services/NotificationService"
import NotificationTemplateModal from "./NotificationTemplateModal"
import NotificationRecipientsModal from "./NotificationRecipientsModal"
import NotificationSendModal from "./NotificationSendModal"

const { TabPane } = Tabs
const { Title } = Typography

const NotificationCenter = () => {
  const [activeTab, setActiveTab] = useState("inbox")
  const [notifications, setNotifications] = useState([])
  const [templates, setTemplates] = useState([])
  const [recipients, setRecipients] = useState([])
  const [rules, setRules] = useState([])
  const [loading, setLoading] = useState(false)
  const [isTemplateModalVisible, setIsTemplateModalVisible] = useState(false)
  const [isRecipientsModalVisible, setIsRecipientsModalVisible] = useState(false)
  const [isSendModalVisible, setIsSendModalVisible] = useState(false)
  const [filterType, setFilterType] = useState("all")

  useEffect(() => {
    if (activeTab === "inbox") {
      fetchNotifications()
    }

    // 🔔 Subscribe to live updates via WebSocket
    // const unsubscribe = notificationService.subscribe("notification", (newNotification) => {
    //   setNotifications((prev) => {
    //     const exists = prev.some((n) => n.id === newNotification.id)
    //     if (exists) return prev
    //     return [newNotification, ...prev]
    //   })
    // })

    const unsubscribe = notificationService.subscribe("notification", (notification) => {
      if (!notification) return // 👈 ignore null or undefined
      setNotifications((prev) => {
        const alreadyExists = prev.some((n) => n.id === notification.id)
        if (alreadyExists) return prev
        return [notification, ...prev]
      })
    })
    

    return () => unsubscribe()
  }, [activeTab])

  const fetchNotifications = async () => {
    setLoading(true)
    try {
      await notificationService.fetchNotifications()
      setNotifications(notificationService.getNotifications())
    } catch (err) {
      console.error("Failed to fetch notifications:", err)
    } finally {
      setLoading(false)
    }
  }
  

  const handleTabChange = (key) => setActiveTab(key)
  const handleFilterChange = (value) => setFilterType(value)

  const markAsRead = (id) => {
    notificationService.markAsRead(id)
    setNotifications([...notificationService.getNotifications()])
  }

  const deleteNotification = (id) => {
    notificationService.deleteNotification(id)
    setNotifications([...notificationService.getNotifications()])
  }  
  
  const inboxColumns = [
    {
      title: "Created time",
      dataIndex: "createdTime",
      key: "createdTime",
      sorter: (a, b) => new Date(a.createdTime) - new Date(b.createdTime),
    },
    { title: "Type", dataIndex: "type", key: "type" },
    { title: "Subject", dataIndex: "title", key: "title" },
    { title: "Message", dataIndex: "message", key: "message" },
    {
      title: "",
      key: "actions",
      render: (_, record) => (
        <Space>
          <Button type="text" icon={<CheckCircleOutlined />} onClick={() => markAsRead(record.id)} />
          {/* <Button type="text" icon={<DeleteOutlined />}  onClick={() => deleteNotification(record.id)} /> */}
          <Button
            type="text"
            icon={<DeleteOutlined />}
            onClick={() => {
              console.log("Deleting notification with ID:", record.id)
              deleteNotification(record.id)
            }}
          />
        </Space>
      ),
    },
  ]

  const renderInboxTab = () => (
    <>
      <div style={{ marginBottom: 16, display: "flex", justifyContent: "space-between" }}>
        <Space>
          <Button type={filterType === "unread" ? "primary" : "default"} onClick={() => handleFilterChange("unread")}>
            Unread
          </Button>
          <Button type={filterType === "all" ? "primary" : "default"} onClick={() => handleFilterChange("all")}>
            All
          </Button>
        </Space>
        <Space>
          <Button icon={<CheckCircleOutlined />} onClick={() => notificationService.markAllAsRead()}>
            Mark all as read
          </Button>
          <Button icon={<ReloadOutlined />} onClick={fetchNotifications} />
          <Button icon={<SearchOutlined />} />
        </Space>
      </div>
      <Table
        columns={inboxColumns}
        dataSource={filterType === "unread" ? notifications.filter((n) => !n.read) : notifications}
        loading={loading}
        rowKey="id"
        pagination={{ pageSize: 10 }}
      />
    </>
  )

  // Other tabs: Templates, Recipients, Rules
  // (No changes to these tabs — if needed, they can be reused as-is)

  return (
    <div className="notification-center">
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
        <Title level={4}>Notification center</Title>
        <Button type="primary" icon={<SendOutlined />} onClick={() => setIsSendModalVisible(true)}>
          Send notification
        </Button>
      </div>
      <Tabs activeKey={activeTab} onChange={handleTabChange}>
        <TabPane tab="Inbox" key="inbox">{renderInboxTab()}</TabPane>
        <TabPane tab="Sent" key="sent">
          <div style={{ padding: 20, textAlign: "center" }}>
            <Typography.Text type="secondary">Sent notifications will appear here</Typography.Text>
          </div>
        </TabPane>
        <TabPane tab="Recipients" key="recipients">
          {/* reuse existing renderRecipientsTab() */}
        </TabPane>
        <TabPane tab="Templates" key="templates">
          {/* reuse existing renderTemplatesTab() */}
        </TabPane>
        <TabPane tab="Rules" key="rules">
          {/* reuse existing renderRulesTab() */}
        </TabPane>
      </Tabs>

      <NotificationTemplateModal
        visible={isTemplateModalVisible}
        onCancel={() => setIsTemplateModalVisible(false)}
        onSave={(template) => {
          setTemplates([...templates, {
            ...template,
            id: Date.now().toString(),
            createdTime: new Date().toISOString()
          }])
          setIsTemplateModalVisible(false)
        }}
      />

      <NotificationRecipientsModal
        visible={isRecipientsModalVisible}
        onCancel={() => setIsRecipientsModalVisible(false)}
        onSave={(recipient) => {
          setRecipients([...recipients, {
            ...recipient,
            id: Date.now().toString(),
            createdTime: new Date().toISOString()
          }])
          setIsRecipientsModalVisible(false)
        }}
      />

      <NotificationSendModal
        visible={isSendModalVisible}
        onCancel={() => setIsSendModalVisible(false)}
        onSend={(notification) => {
          console.log("Sending notification:", notification)
          setIsSendModalVisible(false)
        }}
        templates={templates}
        recipients={recipients}
      />
    </div>
  )
}

export default NotificationCenter
