"use client"

import { useState, useEffect, useRef } from "react"
import { Badge, Dropdown, Button, Typography, List } from "antd"
import { BellOutlined } from "@ant-design/icons"
import notificationService from "../../services/NotificationService"
import NotificationItem from "./NotificationItem"
import "./NotificationBell.css"

const { Text, Title } = Typography

const NotificationBell = ({ token }) => {
  const [unreadCount, setUnreadCount] = useState(0)
  const [notifications, setNotifications] = useState([])
  const [visible, setVisible] = useState(false)
  const [loading, setLoading] = useState(false)
  const dropdownRef = useRef(null)

  useEffect(() => {
    // Connect WebSocket
    try {
      notificationService.connect(token)
    } catch (error) {
      console.error("Failed to connect to notification service:", error)
    }

    // Fetch initial notifications from cache/storage
    notificationService.fetchNotifications().then(() => {
      setNotifications(notificationService.getNotifications())
      setUnreadCount(notificationService.getUnreadCount())
    })

    // Subscribe to real-time events
    const unsubscribeNotification = notificationService.subscribe("notification", (notification) => {
      if (!notification || !notification.id) return // Prevent null crash
      setNotifications((prev) => {
        const alreadyExists = prev.some((n) => n.id === notification.id)
        if (alreadyExists) return prev
        return [notification, ...prev]
      })
    })    

    const unsubscribeUnreadCount = notificationService.subscribe("unreadCountChanged", (count) => {
      setUnreadCount(count)
    })

    // Cleanup
    return () => {
      unsubscribeNotification()
      unsubscribeUnreadCount()
      notificationService.disconnect()
    }
  }, [token])

  const handleVisibleChange = (flag) => {
    setVisible(flag)
  }

  const handleMarkAllAsRead = () => {
    notificationService.markAllAsRead()
    setNotifications([...notificationService.getNotifications()])
    setUnreadCount(0)
  }

  const handleNotificationClick = (notification) => {
    notificationService.markAsRead(notification.id)
    setNotifications([...notificationService.getNotifications()])
    setUnreadCount(notificationService.getUnreadCount())

    if (notification.type === "DEVICE_ADDED") {
      window.location.href = `/devices/${notification.entityId}`
    }
  }

  const menu = (
    <div className="notification-dropdown">
      <div className="notification-header">
        <Title level={5}>Notification</Title>
        <Button type="text" onClick={handleMarkAllAsRead}>
          Mark all as read
        </Button>
      </div>
      <div className="notification-content">
        {notifications.length === 0 ? (
          <div className="notification-empty">
            <Text type="secondary">No notifications</Text>
          </div>
        ) : (
          <List
            dataSource={notifications}
            renderItem={(notification) => (
              <NotificationItem
                notification={notification}
                onClick={() => handleNotificationClick(notification)}
              />
            )}
          />
        )}
      </div>
      <div className="notification-footer">
        <Button type="link" onClick={() => (window.location.href = "/notification-center")}>
          View all
        </Button>
      </div>
    </div>
  )

  return (
    <Dropdown
      overlay={menu}
      trigger={["click"]}
      visible={visible}
      onVisibleChange={handleVisibleChange}
      getPopupContainer={(trigger) => trigger.parentNode}
      overlayClassName="notification-dropdown-overlay"
      placement="bottomRight"
    >
      <Badge count={unreadCount} overflowCount={99} size="small">
        <Button type="text" icon={<BellOutlined />} className="header-icon-button" />
      </Badge>
    </Dropdown>
  )
}

export default NotificationBell
