"use client"

import { useState, useEffect } from "react"
import { Layout, Menu, Button, Drawer } from "antd"
import { Link, useLocation } from "react-router-dom"
import {
  HomeOutlined,
  AlertOutlined,
  DashboardOutlined,
  AppstoreOutlined,
  ApiOutlined,
  SettingOutlined,
  TeamOutlined,
  NodeIndexOutlined,
  CloudServerOutlined,
  ToolOutlined,
  FolderOutlined,
  AppstoreAddOutlined,
  PictureOutlined,
  CodeOutlined,
  CodeSandboxOutlined,
  MenuOutlined,
  CloseOutlined,
  NotificationOutlined,
  ProfileOutlined,
} from "@ant-design/icons"
import logo from "../../assets/iotmining-logo.svg"
import { useMediaQuery } from "../../hooks/useMediaQuery"
import { jwtDecode } from "jwt-decode"

const { Sider } = Layout

const SideNavigation = () => {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [roles, setRoles] = useState([])
  const location = useLocation()
  const isMobile = useMediaQuery("(max-width: 768px)")
  const isTablet = useMediaQuery("(max-width: 992px)")

  useEffect(() => {
    const token = localStorage.getItem("token")
    if (token) {
      try {
        const decoded = jwtDecode(token)
        const userRoles = decoded.role || decoded.roles || []
        setRoles(Array.isArray(userRoles) ? userRoles : [userRoles])
      } catch (err) {
        console.error("Failed to decode token", err)
      }
    }
  }, [])

  const hasRole = (allowedRoles) => roles.some((r) => allowedRoles.includes(r))

  useEffect(() => {
    if (isTablet && !isMobile) {
      setCollapsed(true)
    } else if (!isTablet) {
      setCollapsed(false)
    }
  }, [isTablet, isMobile])

  const menuItems = [
    {
      key: "home",
      icon: <HomeOutlined />,
      label: <Link to="/">Home</Link>,
    },
    {
      key: "alarms",
      icon: <AlertOutlined />,
      label: <Link to="/alarms">Alarms</Link>,
    },
    hasRole(["ROLE_ADMIN", "ROLE_MANAGER"]) && {
      key: "dashboards",
      icon: <DashboardOutlined />,
      label: <Link to="/dashboards">Dashboards</Link>,
    },
    hasRole(["ROLE_ADMIN", "ROLE_SUPPORT"]) && {
      key: "notification",
      icon: <NotificationOutlined />,
      label: <Link to="/notification-center">Notification</Link>,
    },
    {
      key: "entities",
      icon: <AppstoreOutlined />,
      label: "Entities",
      children: [
        {
          key: "devices",
          label: <Link to="/devices">Devices</Link>,
        },
      ],
    },
    // {
    //   key: "assets",
    //   icon: <ApiOutlined />,
    //   label: <Link to="/assets">Assets</Link>,
    // },
    // {
    //   key: "entity-views",
    //   icon: <AppstoreOutlined />,
    //   label: <Link to="/entity-views">Entity views</Link>,
    // },
    // {
    //   key: "gateways",
    //   icon: <CloudServerOutlined />,
    //   label: <Link to="/gateways">Gateways</Link>,
    // },
    {
      key: "profiles",
      icon: <ProfileOutlined />,
      label: "Profiles",
      children: [
        {
          key: "device-profiles",
          label: <Link to="/device-profiles">Device profiles</Link>,
        },
        {
          key: "asset-profiles",
          label: <Link to="/asset-profiles">Asset profiles</Link>,
        },
      ],
    },
    hasRole(["ROLE_ADMIN"]) && {
      key: "customers",
      icon: <TeamOutlined />,
      label: <Link to="/customers">Customers</Link>,
    },
    {
      key: "rule-chains",
      icon: <NodeIndexOutlined />,
      label: <Link to="/rule-chains">Rule chains</Link>,
    },
    // {
    //   key: "edge-management",
    //   icon: <CloudServerOutlined />,
    //   label: "Edge management",
    // },
    // {
    //   key: "advanced-features",
    //   icon: <ToolOutlined />,
    //   label: "Advanced features",
    // },
    // {
    //   key: "resources",
    //   icon: <FolderOutlined />,
    //   label: "Resources",
    //   children: [
    //     {
    //       key: "widgets-library",
    //       icon: <AppstoreAddOutlined />,
    //       label: <Link to="/widgets-library">Widgets library</Link>,
    //     },
    //     {
    //       key: "image-gallery",
    //       icon: <PictureOutlined />,
    //       label: <Link to="/image-gallery">Image gallery</Link>,
    //     },
    //     {
    //       key: "scada-symbols",
    //       icon: <CodeSandboxOutlined />,
    //       label: <Link to="/scada-symbols">SCADA symbols</Link>,
    //     },
    //     {
    //       key: "javascript-library",
    //       icon: <CodeOutlined />,
    //       label: <Link to="/javascript-library">JavaScript library</Link>,
    //     },
    //   ],
    // },
    {
      key: "settings",
      icon: <SettingOutlined />,
      label: <Link to="/settings">Settings</Link>,
    },
  ].filter(Boolean)

  const renderMobileMenu = () => (
    <>
      <Button
        icon={<MenuOutlined />}
        onClick={() => setMobileOpen(true)}
        className="mobile-menu-trigger"
        type="text"
        size="large"
      />

      <Drawer
        title={
          <div className="mobile-logo-container">
            <img src={logo || "/iotmining-logo.svg"} alt="IoT Edge" className="logo" />
            <span className="logo-text">IoT Edge</span>
            <Button
              icon={<CloseOutlined />}
              onClick={() => setMobileOpen(false)}
              className="mobile-menu-close"
              type="text"
            />
          </div>
        }
        placement="left"
        onClose={() => setMobileOpen(false)}
        open={mobileOpen}
        width={280}
        bodyStyle={{ padding: 0 }}
        headerStyle={{ padding: "12px 16px", borderBottom: "1px solid rgba(0,0,0,0.06)" }}
        className="mobile-menu-drawer"
      >
        <Menu
          theme="light"
          mode="inline"
          selectedKeys={[location.pathname.split("/")[1] || "home"]}
          defaultOpenKeys={["entities", "profiles", "resources"]}
          items={menuItems}
          onClick={() => setMobileOpen(false)}
        />
      </Drawer>
    </>
  )

  const renderDesktopSidebar = () => (
    <Sider
      collapsible
      collapsed={collapsed}
      onCollapse={setCollapsed}
      style={{
        overflow: "auto",
        height: "100vh",
        position: "sticky",
        top: 0,
        left: 0,
        backgroundColor: "black",
      }}
      width={220}
      collapsedWidth={80}
      className="desktop-sidebar"
    >
      <div className="logo-container">
        <img src={logo || "/iotmining-logo.svg"} alt="IoT Edge" className="logo" />
        {!collapsed && <span className="logo-text">IoTMining</span>}
      </div>
      <Menu
        theme="dark"
        mode="inline"
        selectedKeys={[location.pathname.split("/")[1] || "home"]}
        defaultOpenKeys={["entities", "profiles", "resources"]}
        style={{ backgroundColor: "black" }}
        items={menuItems}
      />
    </Sider>
  )

  return <>{isMobile ? renderMobileMenu() : renderDesktopSidebar()}</>
}

export default SideNavigation
