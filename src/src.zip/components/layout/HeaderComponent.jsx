"use client"

import { useState } from "react"
import { Layout, Typography, Space, Avatar, Dropdown, Menu, Badge, Button, Tooltip } from "antd"
import { Link, useLocation, useNavigate } from "react-router-dom"
import {
  UserOutlined,
  BellOutlined,
  SettingOutlined,
  LogoutOutlined,
  QuestionCircleOutlined,
} from "@ant-design/icons"
import NotificationBell from "../notification/NotificationBell"
import ThemeToggle from "../theme/ThemeToggle"
import { useTheme } from "../theme/ThemeProvider"

const { Header } = Layout
const { Title } = Typography

const HeaderComponent = () => {
  const location = useLocation()
  const navigate = useNavigate()
  const { theme } = useTheme()
  const [userMenuVisible, setUserMenuVisible] = useState(false)

  // Get page title based on current route
  const getPageTitle = () => {
    const path = location.pathname
    if (path === "/") return "Home"
    if (path === "/devices") return "Devices"
    if (path === "/dashboards") return "Dashboards"
    if (path.startsWith("/dashboards/")) return "Dashboard Editor"
    if (path.startsWith("/customer-dashboard/")) return "Customer Dashboard"
    if (path === "/rule-chains") return "Rule Chains"
    if (path.startsWith("/rule-chains/")) return "Rule Chain Editor"
    if (path === "/customers") return "Customers"
    if (path === "/notification-center") return "Notification Center"
    if (path === "/settings") return "Settings"
    return "ThingsBoard"
  }

  const userMenu = (
    <Menu>
      <Menu.Item key="profile" icon={<UserOutlined />}>
        <Link to="/settings?tab=user">Profile</Link>
      </Menu.Item>
      <Menu.Item key="settings" icon={<SettingOutlined />}>
        <Link to="/settings">Settings</Link>
      </Menu.Item>
      <Menu.Divider />
      <Menu.Item key="help" icon={<QuestionCircleOutlined />}>
        Help Center
      </Menu.Item>
      <Menu.Item key="logout" icon={<LogoutOutlined />} danger>
        Logout
      </Menu.Item>
    </Menu>
  )

  return (
    <Header className="site-header">
      <div className="header-title">
        <Title level={4} className="header-page-title" style={{ margin: 0 }}>
          {getPageTitle()}
        </Title>
      </div>
      <div className="header-actions">
        <Space size="middle">
          <ThemeToggle />
          
          <NotificationBell count={5} />
          
          <Tooltip title="Settings">
            <Button 
              type="text" 
              icon={<SettingOutlined />} 
              onClick={() => navigate('/settings')}
              className="header-icon-button"
            />
          </Tooltip>
          
          <Dropdown
            overlay={userMenu}
            trigger={["click"]}
            visible={userMenuVisible}
            onVisibleChange={setUserMenuVisible}
          >
            <div className="user-dropdown">
              <Space>
                <Avatar icon={<UserOutlined />} />
                <div className="user-info">
                  <div className="user-name">Admin User</div>
                  <div className="user-role">Administrator</div>
                </div>
              </Space>
            </div>
          </Dropdown>
        </Space>
      </div>
    </Header>
  )
}

export default HeaderComponent

// "use client"

// import { Layout, Button, Avatar, Dropdown, Space, Typography, message } from "antd"
// import {
//   FullscreenOutlined,
//   UserOutlined,
//   MoreOutlined,
//   AppstoreOutlined,
//   BellOutlined,
// } from "@ant-design/icons"
// import { useLocation, Link, useNavigate } from "react-router-dom"
// import { useEffect, useState } from "react"
// import NotificationBell from "../notification/NotificationBell"
// import notificationService from "../../services/NotificationService"
// import { useMediaQuery } from "../../hooks/useMediaQuery"

// const { Header } = Layout

// const HeaderComponent = () => {
//   const location = useLocation()
//   const navigate = useNavigate()
//   const path = location.pathname.split("/")[1] || "home"
//   const [token, setToken] = useState(localStorage.getItem("token"))
//   const isMobile = useMediaQuery("(max-width: 768px)")
//   const isSmallMobile = useMediaQuery("(max-width: 480px)")

//   useEffect(() => {
//     if (token) {
//       try {
//         notificationService.connect(token)
//       } catch (error) {
//         console.error("Failed to connect to notification service:", error)
//       }

//       return () => {
//         notificationService.disconnect()
//       }
//     }
//   }, [token])

//   const handleMenuClick = ({ key }) => {
//     if (key === "logout") {
//       localStorage.removeItem("token")
//       setToken(null)
//       message.success("Logged out successfully")
//       navigate("/auth")
//     }
//   }

//   const userMenuItems = [
//     {
//       key: "profile",
//       label: "Profile",
//     },
//     {
//       key: "settings",
//       label: "Settings",
//     },
//     {
//       key: "logout",
//       label: "Logout",
//     },
//   ]

//   const getHeaderTitle = () => {
//     switch (path) {
//       case "home":
//         return "Home"
//       case "devices":
//         return "Devices"
//       default:
//         return path.charAt(0).toUpperCase() + path.slice(1)
//     }
//   }

//   return (
//     <Header className="site-header">
//       <div className="header-title">
//         {isMobile && <div className="mobile-menu-placeholder"></div>}

//         {path === "devices" && !isSmallMobile && (
//           <Link to="/devices">
//             <Button type="text" icon={<AppstoreOutlined />} className="header-icon-button">
//               Devices
//             </Button>
//           </Link>
//         )}

//         {(!["home", "devices"].includes(path) || isSmallMobile) && (
//           <Typography.Title level={4} style={{ margin: 0 }} className="header-page-title">
//             {getHeaderTitle()}
//           </Typography.Title>
//         )}
//       </div>

//       <div className="header-actions">
//         {!isMobile && <Button type="text" icon={<FullscreenOutlined />} className="header-icon-button" />}

//         {isMobile ? (
//           <Button type="text" icon={<BellOutlined />} className="header-icon-button mobile-notification-button" />
//         ) : (
//           <NotificationBell token={token} />
//         )}

//         <Dropdown menu={{ items: userMenuItems, onClick: handleMenuClick }} trigger={["click"]}>
//           <Space className="user-dropdown">
//             <Avatar icon={<UserOutlined />} />
//             {!isSmallMobile && (
//               <div className="user-info">
//                 <div className="user-name">Santosh Kumar</div>
//                 <div className="user-role">Tenant administrator</div>
//               </div>
//             )}
//             <Button type="text" icon={<MoreOutlined />} size="small" />
//           </Space>
//         </Dropdown>
//       </div>
//     </Header>
//   )
// }

// export default HeaderComponent
