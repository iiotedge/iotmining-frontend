"use client"

import { Card, Empty, Spin } from "antd"
import ValueCardWidget from "./widgets/ValueCardWidget"
import StatusCardWidget from "./widgets/StatusCardWidget"
import AlarmTableWidget from "./widgets/AlarmTableWidget"
import AlarmCountWidget from "./widgets/AlarmCountWidget"
import SignalStrengthWidget from "./widgets/SignalStrengthWidget"
import ProgressBarWidget from "./widgets/ProgressBarWidget"
import BatteryLevelWidget from "./widgets/BatteryLevelWidget"
import LineChartWidget from "./widgets/LineChartWidget"
import BarChartWidget from "./widgets/BarChartWidget"
import PieChartWidget from "./widgets/PieChartWidget"
import DoughnutChartWidget from "./widgets/DoughnutChartWidget"
import TimeSeriesChartWidget from "./widgets/TimeSeriesChartWidget"
import GaugeWidget from "./widgets/GaugeWidget"
import MapWidget from "./widgets/MapWidget"
import CameraWidget from "./widgets/CameraWidget" // ✅ added

const WidgetRenderer = ({ widget, config }) => {
  if (!widget) {
    return <Empty description="Widget not found" />
  }

  if (!config || !config.data) {
    return (
      <Card title={widget.title} bordered style={{ height: "auto"}}>
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100%" }}>
          <Spin tip="Loading data..." />
        </div>
      </Card>
    )
  }

  const theme = config.theme || "light"
  const themeClass = `widget-theme-${theme}`

  const renderWidget = () => {
    switch (widget.type) {
      case "value-card":
        return <ValueCardWidget {...config} theme={theme} />
      case "status-card":
        return <StatusCardWidget {...config} theme={theme} />
      case "alarm-table":
        return <AlarmTableWidget {...config} theme={theme} />
      case "alarm-count":
        return <AlarmCountWidget {...config} theme={theme} />
      case "signal-strength":
        return <SignalStrengthWidget {...config} theme={theme} />
      case "progress-bar":
        return <ProgressBarWidget {...config} theme={theme} />
      case "battery-level":
        return <BatteryLevelWidget {...config} theme={theme} />
      case "line-chart":
        return <LineChartWidget {...config} theme={theme} />
      case "bar-chart":
        return <BarChartWidget {...config} theme={theme} />
      case "pie-chart":
        return <PieChartWidget {...config} theme={theme} />
      case "doughnut-chart":
        return <DoughnutChartWidget {...config} theme={theme} />
      case "time-series-chart":
        return <TimeSeriesChartWidget {...config} theme={theme} />
      case "gauge":
        return <GaugeWidget {...config} theme={theme} />
      case "map":
        return <MapWidget {...config} theme={theme} />

      // ✅ Support both "camera" and "camera-feed"
      case "camera":
      case "camera-feed":
        return <CameraWidget {...config} theme={theme} />

      default:
        return <Empty description={`Unknown widget type: ${widget.type}`} image={Empty.PRESENTED_IMAGE_SIMPLE} />
    }
  }

  return <div className={`widget-container ${themeClass}`}>{renderWidget()}</div>
}

export default WidgetRenderer
