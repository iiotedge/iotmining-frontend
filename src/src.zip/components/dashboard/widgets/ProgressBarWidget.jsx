import { Card, Typography, Progress } from "antd"

const { Title, Text } = Typography

const ProgressBarWidget = ({ title = "Progress Bar", progress = 36, color = "#1890ff" }) => {
  return (
    <Card bordered={true} style={{ height: "100%" }}>
      <div style={{ textAlign: "center" }}>
        <Title level={5}>{title}</Title>
        <div style={{ margin: "20px 0" }}>
          <Progress percent={progress} strokeColor={color} status={progress === 100 ? "success" : "active"} />
        </div>
        <Text strong style={{ fontSize: 24 }}>
          {progress}%
        </Text>
      </div>
    </Card>
  )
}

export default ProgressBarWidget
