"use client"

import { useState, useEffect } from "react"
import { Card, Typography } from "antd"

const { Title } = Typography

const MapWidget = ({ title = "Map", data = null }) => {
  const [mapLoaded, setMapLoaded] = useState(false)
  const mapContainerId = `map-${Math.random().toString(36).substring(2, 9)}`

  // Sample data points
  const locations = data || [
    { lat: 37.7749, lng: -122.4194, title: "San Francisco" },
    { lat: 40.7128, lng: -74.006, title: "New York" },
    { lat: 34.0522, lng: -118.2437, title: "Los Angeles" },
    { lat: 41.8781, lng: -87.6298, title: "Chicago" },
  ]

  useEffect(() => {
    // Load Google Maps API script
    if (!window.google) {
      const script = document.createElement("script")
      script.src = `https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places`
      script.async = true
      script.defer = true
      script.onload = () => {
        setMapLoaded(true)
      }
      document.head.appendChild(script)
    } else {
      setMapLoaded(true)
    }

    return () => {
      // Clean up if needed
    }
  }, [])

  useEffect(() => {
    if (mapLoaded && window.google) {
      // Initialize the map
      const map = new window.google.maps.Map(document.getElementById(mapContainerId), {
        center: { lat: 37.7749, lng: -122.4194 },
        zoom: 4,
      })

      // Add markers for each location
      locations.forEach((location) => {
        const marker = new window.google.maps.Marker({
          position: { lat: location.lat, lng: location.lng },
          map,
          title: location.title,
        })

        // Add info window
        const infoWindow = new window.google.maps.InfoWindow({
          content: `<div><strong>${location.title}</strong></div>`,
        })

        marker.addListener("click", () => {
          infoWindow.open(map, marker)
        })
      })
    }
  }, [mapLoaded, locations, mapContainerId])

  // Fallback to a simple map representation if Google Maps API is not loaded
  const renderFallbackMap = () => {
    return (
      <div
        style={{
          height: "100%",
          minHeight: "300px",
          background: "#f0f2f5",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          padding: "20px",
        }}
      >
        <div style={{ fontSize: "48px", marginBottom: "16px" }}>🗺️</div>
        <div>Map loading...</div>
        <div style={{ marginTop: "10px", fontSize: "12px" }}>
          {locations.map((loc, idx) => (
            <div key={idx}>
              {loc.title} ({loc.lat.toFixed(2)}, {loc.lng.toFixed(2)})
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <Card title={title} bordered={true} style={{ height: "100%" }}>
      <div id={mapContainerId} style={{ height: "300px", width: "100%" }}>
        {!mapLoaded && renderFallbackMap()}
      </div>
    </Card>
  )
}

export default MapWidget
