import { Card, Typography } from "antd"
import { WifiOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

const SignalStrengthWidget = ({ title = "Signal Strength", strength = 75 }) => {
  const getColorByStrength = () => {
    if (strength > 70) return "#52c41a"
    if (strength > 30) return "#faad14"
    return "#f5222d"
  }

  const getIconSize = () => {
    if (strength > 70) return 48
    if (strength > 30) return 36
    return 24
  }

  return (
    <Card bordered={true} style={{ height: "100%" }}>
      <div style={{ textAlign: "center" }}>
        <Title level={5}>{title}</Title>
        <div style={{ margin: "20px 0" }}>
          <WifiOutlined style={{ fontSize: getIconSize(), color: getColorByStrength() }} />
        </div>
        <Text strong style={{ fontSize: 24, color: getColorByStrength() }}>
          {strength}%
        </Text>
      </div>
    </Card>
  )
}

export default SignalStrengthWidget
