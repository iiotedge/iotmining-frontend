import { Card, Typography, Badge, Space } from "antd"
import { CheckCircleFilled, CloseCircleFilled, ExclamationCircleFilled } from "@ant-design/icons"

const { Title, Text } = Typography

const StatusCardWidget = ({
  title = "Status Card",
  status = "success", // success, error, warning, processing
  description = "System is running normally",
  lastUpdated = "2 minutes ago",
}) => {
  const getStatusIcon = () => {
    switch (status) {
      case "success":
        return <CheckCircleFilled style={{ fontSize: 24, color: "#52c41a" }} />
      case "error":
        return <CloseCircleFilled style={{ fontSize: 24, color: "#f5222d" }} />
      case "warning":
        return <ExclamationCircleFilled style={{ fontSize: 24, color: "#faad14" }} />
      case "processing":
        return <Badge status="processing" style={{ fontSize: 24 }} />
      default:
        return <CheckCircleFilled style={{ fontSize: 24, color: "#52c41a" }} />
    }
  }

  return (
    <Card bordered={true} style={{ height: "100%" }}>
      <Space direction="vertical" size="large" style={{ width: "100%" }}>
        <Title level={4}>{title}</Title>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          {getStatusIcon()}
          <div>
            <Text strong style={{ fontSize: 16 }}>
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </Text>
            <div>{description}</div>
          </div>
        </div>
        <Text type="secondary">Last updated: {lastUpdated}</Text>
      </Space>
    </Card>
  )
}

export default StatusCardWidget
