import { Card, Typography } from "antd"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

const { Title } = Typography

const TimeSeriesChartWidget = ({ title = "Time Series Chart", data = null }) => {
  // Generate sample data if none provided
  const generateTimeSeriesData = () => {
    const result = []
    const now = new Date()

    for (let i = 0; i < 24; i++) {
      const time = new Date(now)
      time.setHours(now.getHours() - 24 + i)

      result.push({
        time: time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        Temperature: Math.sin(i / 4) * 20 + 50 + Math.random() * 10,
        Humidity: Math.cos(i / 4) * 30 + 40 + Math.random() * 10,
      })
    }

    return result
  }

  const chartData = data || generateTimeSeriesData()

  return (
    <Card title={title} bordered={true} style={{ height: "100%" }}>
      <div style={{ width: "100%", height: 300 }}>
        <ResponsiveContainer>
          <LineChart
            data={chartData}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="Temperature" stroke="#8884d8" activeDot={{ r: 8 }} />
            <Line type="monotone" dataKey="Humidity" stroke="#82ca9d" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}

export default TimeSeriesChartWidget
