import { Card, Typography } from "antd"
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts"

const { Title } = Typography

const GaugeWidget = ({ title = "Gauge", value = 75, min = 0, max = 100 }) => {
  // Calculate percentage
  const percent = value / max
  const data = [
    { name: "value", value: percent },
    { name: "empty", value: 1 - percent },
  ]

  // Determine color based on value
  const getColor = () => {
    if (percent < 0.3) return "#f5222d"
    if (percent < 0.7) return "#faad14"
    return "#52c41a"
  }

  return (
    <Card title={title} bordered={true} style={{ height: "100%" }}>
      <div style={{ width: "100%", height: 300, position: "relative" }}>
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            textAlign: "center",
            zIndex: 1,
          }}
        >
          <div style={{ fontSize: "24px", fontWeight: "bold" }}>{value}</div>
        </div>
        <ResponsiveContainer>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              startAngle={180}
              endAngle={0}
              innerRadius={60}
              outerRadius={80}
              paddingAngle={0}
              dataKey="value"
            >
              <Cell fill={getColor()} />
              <Cell fill="#f0f0f0" />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}

export default GaugeWidget
