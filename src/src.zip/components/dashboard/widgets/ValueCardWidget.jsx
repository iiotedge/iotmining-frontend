import { Card, Typography, Statistic } from "antd"
import { ArrowUpOutlined, ArrowDownOutlined } from "@ant-design/icons"

const { Title } = Typography

const ValueCardWidget = ({
  title = "Value Card",
  value = 75,
  unit = "",
  prefix = "",
  suffix = "",
  trend = 0,
  precision = 0,
  data = [],
  dataKeys = ["value"],
  theme = "light",
}) => {
  // Extract the latest value from data if available
  let displayValue = value
  let displayTrend = trend

  if (data && data.length > 0 && dataKeys && dataKeys.length > 0) {
    const latestData = data[data.length - 1]
    if (latestData && latestData[dataKeys[0]] !== undefined) {
      displayValue = latestData[dataKeys[0]]

      // Calculate trend if we have enough data points
      if (data.length > 1) {
        const previousData = data[data.length - 2]
        if (previousData && previousData[dataKeys[0]] !== undefined) {
          const previousValue = previousData[dataKeys[0]]
          if (previousValue !== 0) {
            displayTrend = ((displayValue - previousValue) / Math.abs(previousValue)) * 100
          }
        }
      }
    }
  }

  // Format the value
  if (typeof displayValue === "number") {
    displayValue = Number(displayValue.toFixed(precision))
  }

  // Determine color based on trend
  const valueColor = displayTrend > 0 ? "#3f8600" : displayTrend < 0 ? "#cf1322" : undefined

  return (
    <Card
      bordered={true}
      style={{ height: "100%" }}
      className={`value-card-widget ${theme === "dark" ? "widget-theme-dark" : ""}`}
    >
      <Statistic
        title={title}
        value={displayValue}
        precision={precision}
        valueStyle={{ color: valueColor }}
        prefix={prefix}
        suffix={suffix || unit}
      />
      {displayTrend !== 0 && (
        <div style={{ marginTop: 8 }}>
          {displayTrend > 0 ? (
            <span style={{ color: "#3f8600" }}>
              <ArrowUpOutlined /> {displayTrend.toFixed(1)}%
            </span>
          ) : (
            <span style={{ color: "#cf1322" }}>
              <ArrowDownOutlined /> {Math.abs(displayTrend).toFixed(1)}%
            </span>
          )}
        </div>
      )}
    </Card>
  )
}

export default ValueCardWidget
