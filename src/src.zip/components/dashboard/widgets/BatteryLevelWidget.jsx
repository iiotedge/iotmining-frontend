import { Card, Typography, Progress } from "antd"
import { PoweroffOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

const BatteryLevelWidget = ({ title = "Battery Level", level = 75 }) => {
  const getColorByLevel = () => {
    if (level > 60) return "#52c41a"
    if (level > 20) return "#faad14"
    return "#f5222d"
  }

  return (
    <Card bordered={true} style={{ height: "100%" }}>
      <div style={{ textAlign: "center" }}>
        <Title level={5}>{title}</Title>
        <div style={{ fontSize: "48px", color: getColorByLevel(), margin: "20px 0" }}>
          <PoweroffOutlined />
        </div>
        <Progress type="line" percent={level} strokeColor={getColorByLevel()} format={(percent) => `${percent}%`} />
      </div>
    </Card>
  )
}

export default BatteryLevelWidget
