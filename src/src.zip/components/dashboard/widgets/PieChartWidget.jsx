import { Card, Typography } from "antd"
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts"

const { Title } = Typography

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#83a6ed"]

const PieChartWidget = ({ title = "Pie Chart", data = null }) => {
  // Generate sample data if none provided
  const chartData = data || [
    { name: "Category 1", value: 27 },
    { name: "Category 2", value: 25 },
    { name: "Category 3", value: 18 },
    { name: "Category 4", value: 15 },
    { name: "Category 5", value: 10 },
    { name: "Others", value: 5 },
  ]

  return (
    <Card title={title} bordered={true} style={{ height: "100%" }}>
      <div style={{ width: "100%", height: 300 }}>
        <ResponsiveContainer>
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              labelLine={true}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}

export default PieChartWidget
