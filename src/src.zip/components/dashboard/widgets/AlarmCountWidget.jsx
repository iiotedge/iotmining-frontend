import { Card, Typography, Statistic } from "antd"
import { AlertOutlined } from "@ant-design/icons"

const { Title } = Typography

const AlarmCountWidget = ({ title = "Alarm Count", count = 3 }) => {
  return (
    <Card bordered={true} style={{ height: "100%" }}>
      <Statistic
        title={title}
        value={count}
        valueStyle={{ color: count > 0 ? "#cf1322" : "#3f8600" }}
        prefix={<AlertOutlined />}
      />
    </Card>
  )
}

export default AlarmCountWidget
