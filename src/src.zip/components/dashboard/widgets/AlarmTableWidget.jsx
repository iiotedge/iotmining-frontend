import { Card, Typography, Table, Tag } from "antd"

const { Title } = Typography

const AlarmTableWidget = ({ title = "Alarm Table", data = null }) => {
  // Generate sample data if none provided
  const alarmData = data || [
    {
      key: "1",
      type: "Temperature",
      severity: "Critical",
      time: "2025-04-20 10:23:45",
      status: "Active",
      device: "Air Filter",
    },
    {
      key: "2",
      type: "Temperature",
      severity: "Major",
      time: "2025-04-20 09:15:22",
      status: "Active",
      device: "IOTM",
    },
    {
      key: "3",
      type: "Low Humidity",
      severity: "Warning",
      time: "2025-04-19 22:45:12",
      status: "Cleared",
      device: "Water level meter",
    },
  ]

  const columns = [
    {
      title: "Type",
      dataIndex: "type",
      key: "type",
    },
    {
      title: "Severity",
      dataIndex: "severity",
      key: "severity",
      render: (severity) => {
        let color = "green"
        if (severity === "Critical") {
          color = "red"
        } else if (severity === "Major") {
          color = "orange"
        } else if (severity === "Warning") {
          color = "gold"
        }
        return <Tag color={color}>{severity}</Tag>
      },
    },
    {
      title: "Time",
      dataIndex: "time",
      key: "time",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => {
        const color = status === "Active" ? "volcano" : "green"
        return <Tag color={color}>{status}</Tag>
      },
    },
    {
      title: "Device",
      dataIndex: "device",
      key: "device",
    },
  ]

  return (
    <Card title={title} bordered={true} style={{ height: "100%" }}>
      <Table columns={columns} dataSource={alarmData} pagination={{ pageSize: 5 }} />
    </Card>
  )
}

export default AlarmTableWidget
