import { Card, Typography } from "antd"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

const { Title } = Typography

const LineChartWidget = ({ title = "Line Chart", data = null }) => {
  // Generate sample data if none provided
  const chartData = data || [
    { name: "Jan", Temperature: 65, Humidity: 28 },
    { name: "Feb", Temperature: 59, Humidity: 48 },
    { name: "Mar", Temperature: 80, Humidity: 40 },
    { name: "Apr", Temperature: 81, Humidity: 47 },
    { name: "May", Temperature: 56, Humidity: 65 },
    { name: "Jun", Temperature: 55, Humidity: 30 },
    { name: "Jul", Temperature: 40, Humidity: 32 },
  ]

  return (
    <Card title={title} bordered={true} style={{ height: "100%" }}>
      <div style={{ width: "100%", height: 300 }}>
        <ResponsiveContainer>
          <LineChart
            data={chartData}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="Temperature" stroke="#8884d8" activeDot={{ r: 8 }} />
            <Line type="monotone" dataKey="Humidity" stroke="#82ca9d" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}

export default LineChartWidget
