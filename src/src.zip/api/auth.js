import axios from "axios"

const BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8080/api/v1"

const apiClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
})

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("token")
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// ✅ Response interceptor to handle token expiry
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("token")
      window.location.href = "/auth" // 🔁 redirect to login
    }
    return Promise.reject(error)
  }
)

export default apiClient
