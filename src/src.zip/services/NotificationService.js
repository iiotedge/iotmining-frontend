let socket = null
let subscribers = {}
let notifications = []
let unreadCount = 0

const STORAGE_KEY = "iot_notifications"

const connect = (token) => {
  if (socket && socket.readyState === WebSocket.OPEN) return
  // const wsUrl = `ws://localhost:8096/ws/notifications?token=${token}`
  const wsUrl = `ws://localhost:8087/ws/notifications`
  socket = new WebSocket(wsUrl)

  socket.onmessage = (event) => {
    try {
      const message = JSON.parse(event.data)
      if (message.type === "NOTIFICATION") {
        const exists = notifications.some(n => n.id === message.payload.id)
        if (!exists) {
          notifications.unshift(message.payload)
          unreadCount++
          save()
          notifySubscribers("notification", message.payload)
          notifySubscribers("unreadCountChanged", unreadCount)
        }
      }
    } catch (err) {
      console.error("WebSocket parse error:", err)
    }
  }

  socket.onclose = () => console.warn("WebSocket closed")
  socket.onerror = (err) => console.error("WebSocket error:", err)
}

const save = () => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications))
}

const fetchNotifications = async () => {
  const raw = localStorage.getItem(STORAGE_KEY)
  notifications = raw ? JSON.parse(raw) : []
  unreadCount = notifications.filter(n => !n.read).length
}

const markAllAsRead = () => {
  notifications = notifications.map(n => ({ ...n, read: true }))
  unreadCount = 0
  save()
}

const markAsRead = (id) => {
  notifications = notifications.map(n =>
    n.id === id ? { ...n, read: true } : n
  )
  unreadCount = notifications.filter(n => !n.read).length
  save()
}

const subscribe = (event, cb) => {
  if (!subscribers[event]) subscribers[event] = []
  subscribers[event].push(cb)
  return () => {
    subscribers[event] = subscribers[event].filter((c) => c !== cb)
  }
}

const notifySubscribers = (event, data) => {
  (subscribers[event] || []).forEach(cb => cb(data))
}

const deleteNotification = (id) => {
  notifications = notifications.filter((n) => n.id !== id)
  unreadCount = notifications.filter((n) => !n.read).length
  notifySubscribers("unreadCountChanged", unreadCount)
}



export default {
  connect,
  disconnect: () => socket?.close(),
  subscribe,
  fetchNotifications,
  getNotifications: () => notifications,
  getUnreadCount: () => unreadCount,
  markAsRead,
  deleteNotification,  // ← add here
  markAllAsRead,
}

// let socket = null
// let subscribers = {}
// let notifications = []
// let unreadCount = 0

// const connect = (token) => {
//   if (socket && socket.readyState === WebSocket.OPEN) return

//   // const wsUrl = `ws://localhost:8087/ws/notifications?token=${token}` // 🔁 adjust if needed
//   const wsUrl = `ws://localhost:8087/ws/notifications`

//   socket = new WebSocket(wsUrl)

//   socket.onopen = () => {
//     console.log("WebSocket connected")
//   }

//   socket.onmessage = (event) => {
//     try {
//       const message = JSON.parse(event.data)

//       // if (message.type === "NOTIFICATION") {
//       //   notifications.unshift(message.payload)
//       //   unreadCount++
//       //   notifySubscribers("notification", message.payload)
//       //   notifySubscribers("unreadCountChanged", unreadCount)
//       // }
//       if (message.type === "NOTIFICATION") {
//         const existing = notifications.find(n => n.id === message.payload.id)
//         if (!existing) {
//           notifications.unshift(message.payload)
//           unreadCount++
//           notifySubscribers("notification", message.payload)
//           notifySubscribers("unreadCountChanged", unreadCount)
//         }
//       }      
//     } catch (error) {
//       console.error("Error parsing WebSocket message:", error)
//     }
//   }

//   socket.onclose = () => {
//     console.warn("WebSocket disconnected")
//   }

//   socket.onerror = (error) => {
//     console.error("WebSocket error:", error)
//   }
// }

// const disconnect = () => {
//   if (socket) {
//     socket.close()
//     socket = null
//   }
// }

// const subscribe = (event, callback) => {
//   if (!subscribers[event]) {
//     subscribers[event] = []
//   }
//   subscribers[event].push(callback)

//   return () => {
//     subscribers[event] = subscribers[event].filter((cb) => cb !== callback)
//   }
// }

// const notifySubscribers = (event, data) => {
//   if (subscribers[event]) {
//     subscribers[event].forEach((cb) => cb(data))
//   }
// }

// // Optional: simulate fetching from server on initial load
// const fetchNotifications = async () => {
//   // Simulate server call or replace with actual API
//   await new Promise((resolve) => setTimeout(resolve, 500))
//   // You can preload from localStorage or server here if needed
// }

// const markAllAsRead = () => {
//   notifications = notifications.map((n) => ({ ...n, read: true }))
//   unreadCount = 0
//   notifySubscribers("unreadCountChanged", unreadCount)
// }

// const markAsRead = (id) => {
//   notifications = notifications.map((n) =>
//     n.id === id ? { ...n, read: true } : n
//   )
//   unreadCount = notifications.filter((n) => !n.read).length
//   notifySubscribers("unreadCountChanged", unreadCount)
// }

// const getNotifications = () => notifications
// const getUnreadCount = () => unreadCount

// export default {
//   connect,
//   disconnect,
//   subscribe,
//   fetchNotifications,
//   markAllAsRead,
//   markAsRead,
//   getNotifications,
//   getUnreadCount,
// }
