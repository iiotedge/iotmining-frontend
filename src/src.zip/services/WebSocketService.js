class WebSocketService {
  constructor() {
    this.socket = null
    this.connected = false
    this.reconnectAttempts = 0
    this.maxReconnectAttempts = 5
    this.reconnectTimeout = 2000
    this.listeners = new Map()
    this.messageQueue = []
  }

  // Connect to WebSocket server
  connect(url, token) {
    return new Promise((resolve, reject) => {
      if (this.socket) {
        this.disconnect()
      }

      const wsUrl = token ? `${url}?token=${token}` : url
      this.socket = new WebSocket(wsUrl)

      this.socket.onopen = () => {
        console.log("WebSocket connection established")
        this.connected = true
        this.reconnectAttempts = 0

        // Send any queued messages
        while (this.messageQueue.length > 0) {
          const message = this.messageQueue.shift()
          this.sendMessage(message)
        }

        resolve()
      }

      this.socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          this.handleMessage(data)
        } catch (e) {
          console.error("Error parsing WebSocket message:", e)
        }
      }

      this.socket.onclose = (event) => {
        this.connected = false
        console.log("WebSocket connection closed", event.code, event.reason)

        // Attempt to reconnect
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
          setTimeout(() => {
            this.reconnectAttempts++
            this.connect(url, token).catch((err) => {
              console.error("WebSocket reconnection failed:", err)
            })
          }, this.reconnectTimeout * Math.pow(2, this.reconnectAttempts))
        }

        reject(new Error(`WebSocket closed: ${event.code} ${event.reason}`))
      }

      this.socket.onerror = (error) => {
        console.error("WebSocket error:", error)
        reject(error)
      }
    })
  }

  // Disconnect WebSocket
  disconnect() {
    if (this.socket) {
      this.socket.close()
      this.socket = null
      this.connected = false
    }
  }

  // Send message through WebSocket
  sendMessage(message) {
    if (this.connected && this.socket) {
      this.socket.send(JSON.stringify(message))
    } else {
      // Queue message to be sent when connection is established
      this.messageQueue.push(message)
    }
  }

  // Handle incoming message
  handleMessage(message) {
    const { type, data } = message

    if (this.listeners.has(type)) {
      this.listeners.get(type).forEach((callback) => {
        callback(data)
      })
    }

    // Also trigger 'all' listeners
    if (this.listeners.has("all")) {
      this.listeners.get("all").forEach((callback) => {
        callback(message)
      })
    }
  }

  // Subscribe to message type
  subscribe(type, callback) {
    if (!this.listeners.has(type)) {
      this.listeners.set(type, [])
    }

    this.listeners.get(type).push(callback)

    // Return unsubscribe function
    return () => {
      const callbacks = this.listeners.get(type)
      const index = callbacks.indexOf(callback)
      if (index !== -1) {
        callbacks.splice(index, 1)
      }
    }
  }

  // Check if connected
  isConnected() {
    return this.connected
  }
}

// Create singleton instance
const webSocketService = new WebSocketService()

export default webSocketService
